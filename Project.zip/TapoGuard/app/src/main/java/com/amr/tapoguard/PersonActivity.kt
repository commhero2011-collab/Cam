package com.amr.tapoguard

import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.GridLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.Spinner
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.dialog.MaterialAlertDialogBuilder

class PersonActivity : AppCompatActivity() {
    private var pid = -1L
    private lateinit var root: LinearLayout
    private val pick = registerForActivityResult(ActivityResultContracts.GetMultipleContents()) { uris ->
        if (uris.isNotEmpty()) enroll(uris)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        pid = intent.getLongExtra("id", -1L)
        root = vbox(); setScroll(root)
        render()
    }

    private fun render() {
        val p = App.db.person(pid) ?: run { finish(); return }
        title = p.name
        root.removeAllViews()
        val name = field("Name", p.name)
        val role = Spinner(this).apply {
            adapter = ArrayAdapter(this@PersonActivity, android.R.layout.simple_spinner_dropdown_item, ROLES)
            setSelection(ROLES.indexOf(p.role).coerceAtLeast(0))
        }
        val auth = check("Allowed to touch / use the car (no alert)", p.authorized)
        root.add(name, top = 0)
        root.add(label("Role (Blocked = alert whenever this person is seen)", 13f, color = Color.GRAY))
        root.add(role); root.add(auth)
        root.add(btn("Save") {
            p.name = name.text.toString().trim().ifEmpty { p.name }
            p.role = ROLES[role.selectedItemPosition]
            p.authorized = auth.isChecked
            App.db.updatePerson(p); App.faces.reloadPeople()
            toast("Saved"); render()
        })

        val faces = App.db.faces(pid)
        root.add(label("Face samples (${faces.size}) – long-press to delete", 16f, true), top = 16)
        val grid = GridLayout(this).apply { columnCount = 4 }
        for ((fid, path) in faces) {
            val iv = ImageView(this).apply {
                scaleType = ImageView.ScaleType.CENTER_CROP
                loadThumb(path, 1)?.let { setImageBitmap(it) }
                setOnLongClickListener {
                    MaterialAlertDialogBuilder(this@PersonActivity).setTitle("Delete this face sample?")
                        .setPositiveButton("Delete") { _, _ ->
                            App.db.deleteFace(fid)
                            Thread { App.faces.reloadGallery() }.start()
                            render()
                        }.setNegativeButton("Cancel", null).show()
                    true
                }
            }
            grid.addView(iv, GridLayout.LayoutParams().apply { width = dp(78); height = dp(78); setMargins(4, 4, 4, 4) })
        }
        root.add(grid)
        root.add(btn("+ Add face photos from gallery") { pick.launch("image/*") })
        root.add(btn("Delete person") {
            MaterialAlertDialogBuilder(this).setTitle("Delete ${p.name}?")
                .setPositiveButton("Delete") { _, _ ->
                    App.db.deletePerson(pid)
                    Thread { App.faces.reloadGallery() }.start()
                    finish()
                }.setNegativeButton("Cancel", null).show()
        }, top = 24)
    }

    private fun enroll(uris: List<Uri>) {
        toast("Detecting faces in ${uris.size} photo(s)…")
        Thread {
            var added = 0
            for (u in uris) {
                val bmp = decodeUri(u) ?: continue
                val face = App.faces.extractFaces(bmp).firstOrNull() ?: continue
                App.faces.saveFaceSample(pid, face)
                added++
            }
            App.faces.reloadGallery()
            runOnUiThread {
                toast(if (added == 0) "No clear face found – use close, front-facing photos" else "Added $added face sample(s)")
                render()
            }
        }.start()
    }
}
