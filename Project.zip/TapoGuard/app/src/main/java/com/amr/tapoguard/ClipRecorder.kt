package com.amr.tapoguard

import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaFormat
import android.media.MediaMuxer
import android.os.Handler
import android.os.HandlerThread
import android.util.Log
import android.view.Surface
import java.io.File

/** Records frames grabbed from the live view into an H.264 MP4 clip (hardware encoder). */
class ClipRecorder(val file: File, private val w: Int = 1280, private val h: Int = 720) {
    private val thread = HandlerThread("recorder").apply { start() }
    private val handler = Handler(thread.looper)
    private var codec: MediaCodec? = null
    private var surface: Surface? = null
    private var muxer: MediaMuxer? = null
    private var track = -1
    private var muxStarted = false
    private val info = MediaCodec.BufferInfo()
    private val paint = Paint(Paint.FILTER_BITMAP_FLAG)
    private val txt = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; textSize = 30f; isFakeBoldText = true; setShadowLayer(3f, 1f, 1f, Color.BLACK) }
    private val dst = Rect(0, 0, w, h)

    @Volatile var isRecording = false
        private set
    var onFinished: ((File?) -> Unit)? = null

    fun start(): Boolean = try {
        val fmt = MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_AVC, w, h).apply {
            setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface)
            setInteger(MediaFormat.KEY_BIT_RATE, 3_000_000)
            setInteger(MediaFormat.KEY_FRAME_RATE, 8)
            setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1)
        }
        val c = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_VIDEO_AVC)
        c.configure(fmt, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
        surface = c.createInputSurface()
        c.start()
        codec = c
        muxer = MediaMuxer(file.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
        isRecording = true
        true
    } catch (e: Exception) {
        Log.e(TAG, "recorder start", e); release(); false
    }

    fun submit(bmp: Bitmap) {
        if (!isRecording) return
        handler.post {
            if (!isRecording) return@post
            try {
                val s = surface ?: return@post
                val cv = s.lockHardwareCanvas()
                cv.drawColor(Color.BLACK)
                cv.drawBitmap(bmp, null, dst, paint)
                cv.drawText(timeStr(System.currentTimeMillis()), 20f, h - 24f, txt)
                s.unlockCanvasAndPost(cv)
                drain(false)
            } catch (e: Exception) { Log.w(TAG, "recorder frame", e) }
        }
    }

    fun stop() {
        if (!isRecording) return
        isRecording = false
        handler.post {
            try { codec?.signalEndOfInputStream(); drain(true) } catch (e: Exception) { Log.w(TAG, e) }
            val ok = muxStarted
            release()
            if (!ok) file.delete()
            onFinished?.invoke(if (ok) file else null)
            thread.quitSafely()
        }
    }

    private fun release() {
        try { codec?.stop() } catch (_: Exception) {}
        try { codec?.release() } catch (_: Exception) {}
        try { if (muxStarted) muxer?.stop() } catch (_: Exception) {}
        try { muxer?.release() } catch (_: Exception) {}
        try { surface?.release() } catch (_: Exception) {}
        codec = null; muxer = null; surface = null
    }

    private fun drain(endOfStream: Boolean) {
        val c = codec ?: return
        val m = muxer ?: return
        val deadline = System.currentTimeMillis() + 3000
        while (true) {
            val idx = c.dequeueOutputBuffer(info, if (endOfStream) 10_000L else 0L)
            if (idx == MediaCodec.INFO_TRY_AGAIN_LATER) {
                if (!endOfStream || System.currentTimeMillis() > deadline) return
            } else if (idx == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                if (!muxStarted) { track = m.addTrack(c.outputFormat); m.start(); muxStarted = true }
            } else if (idx >= 0) {
                val buf = c.getOutputBuffer(idx)
                if ((info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG) != 0) info.size = 0
                if (info.size > 0 && muxStarted && buf != null) {
                    buf.position(info.offset); buf.limit(info.offset + info.size)
                    m.writeSampleData(track, buf, info)
                }
                c.releaseOutputBuffer(idx, false)
                if ((info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) return
            }
        }
    }
}
