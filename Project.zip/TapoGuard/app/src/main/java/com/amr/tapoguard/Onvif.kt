package com.amr.tapoguard

import android.util.Base64
import android.util.Log
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest
import java.security.SecureRandom
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import java.util.concurrent.Executors

/** Minimal ONVIF PTZ client for Tapo C200 (ONVIF port 2020, uses the Tapo "Camera Account"). */
class Onvif(private val ip: String, private val user: String, private val pass: String) {
    private val url = "http://$ip:2020/onvif/service"
    private val exec = Executors.newSingleThreadExecutor()
    @Volatile private var profile: String? = null
    var onError: ((String) -> Unit)? = null

    private fun esc(s: String) = s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")

    private fun header(): String {
        val nonce = ByteArray(16).also { SecureRandom().nextBytes(it) }
        val created = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US)
            .apply { timeZone = TimeZone.getTimeZone("UTC") }.format(Date())
        val md = MessageDigest.getInstance("SHA-1")
        md.update(nonce); md.update(created.toByteArray()); md.update(pass.toByteArray())
        val digest = Base64.encodeToString(md.digest(), Base64.NO_WRAP)
        val n64 = Base64.encodeToString(nonce, Base64.NO_WRAP)
        return "<s:Header><Security s:mustUnderstand=\"1\" xmlns=\"http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd\">" +
            "<UsernameToken><Username>${esc(user)}</Username>" +
            "<Password Type=\"http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-username-token-profile-1.0#PasswordDigest\">$digest</Password>" +
            "<Nonce EncodingType=\"http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-soap-message-security-1.0#Base64Binary\">$n64</Nonce>" +
            "<Created xmlns=\"http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-utility-1.0.xsd\">$created</Created>" +
            "</UsernameToken></Security></s:Header>"
    }

    private fun post(body: String): String {
        val env = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>" +
            "<s:Envelope xmlns:s=\"http://www.w3.org/2003/05/soap-envelope\">${header()}<s:Body>$body</s:Body></s:Envelope>"
        val c = URL(url).openConnection() as HttpURLConnection
        c.requestMethod = "POST"; c.doOutput = true; c.connectTimeout = 4000; c.readTimeout = 6000
        c.setRequestProperty("Content-Type", "application/soap+xml; charset=utf-8")
        c.outputStream.use { it.write(env.toByteArray()) }
        val code = c.responseCode
        val resp = (if (code >= 400) c.errorStream else c.inputStream)?.bufferedReader()?.readText() ?: ""
        c.disconnect()
        if (code >= 400) throw IllegalStateException("ONVIF HTTP $code")
        return resp
    }

    private fun profileToken(): String {
        profile?.let { return it }
        val r = post("<GetProfiles xmlns=\"http://www.onvif.org/ver10/media/wsdl\"/>")
        val m = Regex("(?:[A-Za-z0-9_]+:)?Profiles[^>]*token=\"([^\"]+)\"").find(r) ?: throw IllegalStateException("No ONVIF profile")
        return m.groupValues[1].also { profile = it }
    }

    fun move(x: Float, y: Float) = exec.execute {
        try {
            val p = esc(profileToken())
            val xs = String.format(Locale.US, "%.2f", x); val ys = String.format(Locale.US, "%.2f", y)
            post("<ContinuousMove xmlns=\"http://www.onvif.org/ver20/ptz/wsdl\"><ProfileToken>$p</ProfileToken>" +
                "<Velocity><PanTilt x=\"$xs\" y=\"$ys\" xmlns=\"http://www.onvif.org/ver10/schema\"/></Velocity></ContinuousMove>")
        } catch (e: Exception) { Log.w(TAG, "PTZ move", e); onError?.invoke(e.message ?: "PTZ error") }
    }

    fun stop() = exec.execute {
        try {
            val p = esc(profileToken())
            post("<Stop xmlns=\"http://www.onvif.org/ver20/ptz/wsdl\"><ProfileToken>$p</ProfileToken><PanTilt>true</PanTilt><Zoom>false</Zoom></Stop>")
        } catch (e: Exception) { Log.w(TAG, "PTZ stop", e) }
    }

    fun shutdown() = exec.shutdown()
}
