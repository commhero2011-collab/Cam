package com.amr.tapoguard

import android.app.Application

class App : Application() {
    override fun onCreate() {
        super.onCreate()
        instance = this
        Prefs.init(this)
        Alerts.createChannels(this)
        Thread {
            try { db.purge(Prefs.retentionDays) } catch (_: Exception) {}
            faces; objects   // warm up AI engines in background
        }.start()
    }

    companion object {
        lateinit var instance: App
        val db: Db by lazy { Db(instance) }
        val faces: FaceEngine by lazy { FaceEngine(instance).also { it.reloadGallery() } }
        val objects: ObjectEngine by lazy { ObjectEngine(instance) }
    }
}
