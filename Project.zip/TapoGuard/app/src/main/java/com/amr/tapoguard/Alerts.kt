package com.amr.tapoguard

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.os.Build
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import java.io.ByteArrayOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

object Alerts {
    private const val CH_ALERT = "alerts_high"
    private const val CH_INFO = "events_info"
    private var nid = 1000

    fun createChannels(ctx: Context) {
        val nm = ctx.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CH_ALERT, "Security alerts", NotificationManager.IMPORTANCE_HIGH).apply { enableVibration(true) }
        )
        nm.createNotificationChannel(NotificationChannel(CH_INFO, "Events", NotificationManager.IMPORTANCE_DEFAULT))
    }

    fun notify(title: String, text: String, bmp: Bitmap?, high: Boolean) {
        val ctx = App.instance
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) return
        val pi = PendingIntent.getActivity(
            ctx, 0, Intent(ctx, EventsActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val b = NotificationCompat.Builder(ctx, if (high) CH_ALERT else CH_INFO)
            .setSmallIcon(R.drawable.ic_stat)
            .setContentTitle(title)
            .setContentText(text)
            .setPriority(if (high) NotificationCompat.PRIORITY_HIGH else NotificationCompat.PRIORITY_DEFAULT)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setAutoCancel(true)
            .setContentIntent(pi)
        if (bmp != null) {
            val w = 720
            val s = Bitmap.createScaledBitmap(bmp, w, (bmp.height * w / bmp.width.toFloat()).toInt(), true)
            b.setStyle(NotificationCompat.BigPictureStyle().bigPicture(s).setSummaryText(text))
        }
        try { NotificationManagerCompat.from(ctx).notify(nid++, b.build()) } catch (e: SecurityException) { Log.w(TAG, e) }
    }

    /** Remote alert to your phone anywhere via a Telegram bot (optional). */
    fun telegram(caption: String, bmp: Bitmap?) {
        val token = Prefs.tgToken.trim(); val chat = Prefs.tgChat.trim()
        if (token.isEmpty() || chat.isEmpty()) return
        Thread {
            try {
                if (bmp == null) {
                    val conn = URL("https://api.telegram.org/bot$token/sendMessage").openConnection() as HttpURLConnection
                    conn.requestMethod = "POST"; conn.doOutput = true
                    conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded")
                    val body = "chat_id=" + URLEncoder.encode(chat, "UTF-8") + "&text=" + URLEncoder.encode(caption, "UTF-8")
                    conn.outputStream.use { it.write(body.toByteArray()) }
                    Log.i(TAG, "Telegram text -> ${conn.responseCode}"); conn.disconnect()
                } else {
                    val boundary = "----TapoGuard${System.currentTimeMillis()}"
                    val conn = URL("https://api.telegram.org/bot$token/sendPhoto").openConnection() as HttpURLConnection
                    conn.requestMethod = "POST"; conn.doOutput = true
                    conn.setRequestProperty("Content-Type", "multipart/form-data; boundary=$boundary")
                    val jpg = ByteArrayOutputStream().also { bmp.compress(Bitmap.CompressFormat.JPEG, 85, it) }.toByteArray()
                    conn.outputStream.use { os ->
                        fun field(name: String, value: String) {
                            os.write("--$boundary\r\nContent-Disposition: form-data; name=\"$name\"\r\n\r\n$value\r\n".toByteArray())
                        }
                        field("chat_id", chat)
                        field("caption", caption.take(1000))
                        os.write("--$boundary\r\nContent-Disposition: form-data; name=\"photo\"; filename=\"alert.jpg\"\r\nContent-Type: image/jpeg\r\n\r\n".toByteArray())
                        os.write(jpg)
                        os.write("\r\n--$boundary--\r\n".toByteArray())
                    }
                    Log.i(TAG, "Telegram photo -> ${conn.responseCode}"); conn.disconnect()
                }
            } catch (e: Exception) { Log.w(TAG, "Telegram failed", e) }
        }.start()
    }
}
