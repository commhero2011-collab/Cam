package com.amr.tapoguard

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.widget.ImageView
import android.widget.LinearLayout
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.dialog.MaterialAlertDialogBuilder

class PeopleActivity : AppCompatActivity() {
    private lateinit var root: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        title = "People & face library"
        root = vbox(); setScroll(root)
    }

    override fun onResume() { super.onResume(); render() }

    private fun render() {
        root.removeAllViews()
        root.add(label("Link faces to characters: add each person, set their role and whether they may touch the car, " +
            "then add 3–10 clear face photos (different angles & lighting). You can also label faces captured by the camera in “Unknown faces”.", 13f, color = Color.GRAY), top = 0)
        root.add(btn("+ Add person") { addPerson() })
        root.add(btn("❓ Unknown faces (${App.db.unknowns().size})") { startActivity(Intent(this, UnknownActivity::class.java)) })
        root.add(btn("↻ Rebuild face index") {
            toast("Rebuilding…")
            Thread { App.faces.reloadGallery(); runOnUiThread { toast("Face index rebuilt") } }.start()
        })
        for (p in App.db.people()) {
            val faces = App.db.faces(p.id)
            val row = hbox()
            val img = ImageView(this).apply {
                scaleType = ImageView.ScaleType.CENTER_CROP
                val b = loadThumb(faces.firstOrNull()?.second, 2)
                if (b != null) setImageBitmap(b) else setBackgroundColor(Color.DKGRAY)
            }
            row.addView(img, LinearLayout.LayoutParams(dp(64), dp(64)))
            val info = vbox(8)
            info.add(label(p.name, 17f, true), top = 0)
            info.add(label("${p.role} • ${if (p.authorized) "✅ allowed at car" else "🚫 alert at car"} • ${faces.size} face sample(s)", 13f, color = Color.GRAY), top = 0)
            row.addView(info, LinearLayout.LayoutParams(0, WRAP, 1f))
            row.setOnClickListener { startActivity(Intent(this, PersonActivity::class.java).putExtra("id", p.id)) }
            root.add(card(row))
        }
    }

    private fun addPerson() {
        val name = field("Name (e.g. Amr, Driver Ali)")
        val box = vbox(16); box.add(name, top = 0)
        MaterialAlertDialogBuilder(this).setTitle("New person").setView(box)
            .setPositiveButton("Create") { _, _ ->
                val n = name.text.toString().trim()
                if (n.isNotEmpty()) {
                    val id = App.db.addPerson(n, "Family", true)
                    App.faces.reloadPeople()
                    startActivity(Intent(this, PersonActivity::class.java).putExtra("id", id))
                }
            }.setNegativeButton("Cancel", null).show()
    }
}
