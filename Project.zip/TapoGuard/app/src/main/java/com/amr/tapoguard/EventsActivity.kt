package com.amr.tapoguard

import android.content.Intent
import android.graphics.BitmapFactory
import android.graphics.Color
import android.os.Bundle
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import java.io.File

class EventsActivity : AppCompatActivity() {
    private var alertsOnly = false
    private lateinit var list: RecyclerView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        title = "Events & recordings"
        val root = vbox(8)
        val bar = hbox()
        bar.addWeighted(btn("All") { alertsOnly = false; load() })
        bar.addWeighted(btn("Alerts") { alertsOnly = true; load() })
        bar.addWeighted(btn("Clear") {
            MaterialAlertDialogBuilder(this).setTitle("Delete all events, snapshots and clips?")
                .setPositiveButton("Delete") { _, _ -> App.db.clearEvents(); load() }
                .setNegativeButton("Cancel", null).show()
        })
        root.add(bar, top = 0)
        list = RecyclerView(this).apply { layoutManager = LinearLayoutManager(this@EventsActivity) }
        root.addView(list, LinearLayout.LayoutParams(MATCH, 0, 1f))
        setContentView(root)
    }

    override fun onResume() { super.onResume(); load() }

    private fun load() { list.adapter = Adapter(App.db.events(alertsOnly)) }

    private fun icon(type: String) = when (type) {
        "CAR_INTERACTION" -> "⚠️"; "CAR_LEFT" -> "🚗💨"; "CAR_PARKED" -> "🅿️"; "CAR_AUTHORIZED" -> "✅"
        "BLOCKED_PERSON" -> "⛔"; "UNKNOWN_PERSON" -> "❓"; "KNOWN_PERSON" -> "👤"; "MOTION" -> "〰️"; "RECORDING" -> "🎬"
        else -> "•"
    }

    class VH(root: LinearLayout, val img: ImageView, val title: TextView, val sub: TextView) : RecyclerView.ViewHolder(root)

    inner class Adapter(private val items: List<EventItem>) : RecyclerView.Adapter<VH>() {
        override fun getItemCount() = items.size
        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
            val ctx = parent.context
            val row = ctx.hbox().apply { setPadding(ctx.dp(4), ctx.dp(6), ctx.dp(4), ctx.dp(6)) }
            row.layoutParams = RecyclerView.LayoutParams(MATCH, WRAP)
            val img = ImageView(ctx).apply { scaleType = ImageView.ScaleType.CENTER_CROP; setBackgroundColor(Color.DKGRAY) }
            row.addView(img, LinearLayout.LayoutParams(ctx.dp(112), ctx.dp(63)))
            val col = ctx.vbox(8)
            val t = ctx.label("", 14f, true); val s = ctx.label("", 12f, color = Color.GRAY)
            col.addView(t); col.addView(s)
            row.addView(col, LinearLayout.LayoutParams(0, WRAP, 1f))
            return VH(row, img, t, s)
        }
        override fun onBindViewHolder(h: VH, position: Int) {
            val e = items[position]
            h.title.text = "${icon(e.type)} ${e.message}"
            h.sub.text = "${timeStr(e.ts)} • ${e.camera}" + (if (e.clip != null) " • 🎬 clip" else "") + (if (e.alert) " • ALERT" else "")
            val b = loadThumb(e.image, 8)
            if (b != null) h.img.setImageBitmap(b) else h.img.setImageDrawable(null)
            h.itemView.setOnClickListener { show(e) }
        }
    }

    private fun show(e: EventItem) {
        val iv = ImageView(this).apply { adjustViewBounds = true }
        e.image?.let { p -> BitmapFactory.decodeFile(p)?.let { iv.setImageBitmap(it) } }
        val d = MaterialAlertDialogBuilder(this).setTitle(e.message).setView(iv)
        if (e.clip != null && File(e.clip).exists()) d.setPositiveButton("▶ Play clip") { _, _ -> openFile(File(e.clip), "video/mp4", false) }
        if (e.image != null && File(e.image).exists()) d.setNeutralButton("Share") { _, _ -> openFile(File(e.image), "image/jpeg", true) }
        d.setNegativeButton("Delete") { _, _ -> App.db.deleteEvent(e); load() }
        d.show()
    }

    private fun openFile(f: File, mime: String, share: Boolean) {
        val uri = uriFor(f)
        val i = if (share) Intent(Intent.ACTION_SEND).setType(mime).putExtra(Intent.EXTRA_STREAM, uri)
        else Intent(Intent.ACTION_VIEW).setDataAndType(uri, mime)
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        try { startActivity(if (share) Intent.createChooser(i, "Share") else i) } catch (ex: Exception) { toast("No app found to open this file") }
    }
}
