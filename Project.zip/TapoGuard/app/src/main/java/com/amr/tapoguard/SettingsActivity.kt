package com.amr.tapoguard

import android.graphics.Color
import android.os.Bundle
import android.text.InputType
import android.widget.LinearLayout
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import java.io.File

class SettingsActivity : AppCompatActivity() {
    private lateinit var root: LinearLayout
    private val num = InputType.TYPE_CLASS_NUMBER
    private val dec = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL

    private val pickModel = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            toast("Importing face model…")
            Thread {
                try {
                    contentResolver.openInputStream(uri)?.use { inp ->
                        File(filesDir, "face_model.tflite").outputStream().use { inp.copyTo(it) }
                    }
                    App.faces.loadModel(); App.faces.reloadGallery()
                    runOnUiThread { toast(App.faces.modelInfo); render() }
                } catch (e: Exception) { runOnUiThread { toast("Import failed: ${e.message}") } }
            }.start()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        title = "Settings & alerts"
        root = vbox(); setScroll(root)
        render()
    }

    private fun section(s: String) = root.add(label(s, 17f, true), top = 18)

    private fun render() {
        root.removeAllViews()
        section("Alert rules")
        val armed = check("Alerts armed", Prefs.armed)
        val autoCars = check("Auto-protect parked cars detected by AI (in addition to drawn zones)", Prefs.autoProtectCars)
        val carLeft = check("Alert when a protected car leaves / disappears", Prefs.carLeftAlert)
        val alertUnknown = check("Alert for ANY unknown person (not only at the car)", Prefs.alertUnknown)
        val notifyKnown = check("Notify when a known person is recognised", Prefs.notifyKnown)
        val motion = check("Motion alerts (noisy outdoors)", Prefs.motionAlerts)
        val clips = check("Record a video clip on every alert", Prefs.recordClips)
        listOf(armed, autoCars, carLeft, alertUnknown, notifyKnown, motion, clips).forEach { root.add(it, top = 0) }

        root.add(label("Seconds a person must stay at the car before alert", 13f, color = Color.GRAY))
        val dwell = field("Dwell seconds", Prefs.dwellSec.toString(), num); root.add(dwell, top = 0)
        root.add(label("Minimum seconds between repeated alerts", 13f, color = Color.GRAY))
        val cooldown = field("Cooldown seconds", Prefs.cooldownSec.toString(), num); root.add(cooldown, top = 0)
        root.add(label("Clip length (seconds)", 13f, color = Color.GRAY))
        val clipSec = field("Clip seconds", Prefs.clipSec.toString(), num); root.add(clipSec, top = 0)

        section("Face recognition")
        root.add(label(App.faces.modelInfo, 13f))
        root.add(label("Match threshold (deep model, 0.45–0.80; higher = stricter, fewer false matches)", 13f, color = Color.GRAY))
        val thr = field("0.60", Prefs.faceThreshold.toString(), dec); root.add(thr, top = 0)
        root.add(label("Legacy pixel-signature threshold (not used for authorisation)", 13f, color = Color.GRAY))
        val bthr = field("0.88", Prefs.basicThreshold.toString(), dec); root.add(bthr, top = 0)
        root.add(label("Minimum face width in pixels to save an unknown face", 13f, color = Color.GRAY))
        val minFace = field("56", Prefs.minFacePx.toString(), num); root.add(minFace, top = 0)
        root.add(btn("Import face model (.tflite, e.g. MobileFaceNet)") { pickModel.launch(arrayOf("*/*")) })
        if (File(filesDir, "face_model.tflite").exists()) root.add(btn("Remove imported model (use bundled/basic)") {
            File(filesDir, "face_model.tflite").delete()
            Thread { App.faces.loadModel(); App.faces.reloadGallery(); runOnUiThread { render() } }.start()
        })

        section("Performance")
        root.add(label("AI interval in ms (lower = faster reaction, more battery/heat)", 13f, color = Color.GRAY))
        val interval = field("500", Prefs.intervalMs.toString(), num); root.add(interval, top = 0)
        root.add(label("Analysis width in pixels (1280 default, 1920 = better faces at distance, slower)", 13f, color = Color.GRAY))
        val aw = field("1280", Prefs.analysisWidth.toString(), num); root.add(aw, top = 0)
        root.add(label("Keep events for N days", 13f, color = Color.GRAY))
        val keep = field("14", Prefs.retentionDays.toString(), num); root.add(keep, top = 0)

        section("Remote alerts via Telegram (optional)")
        root.add(label("Create a bot with @BotFather → paste the token. Send any message to your bot, then get your chat id " +
            "(e.g. from @userinfobot). Alerts with photo will reach your phone anywhere.", 13f, color = Color.GRAY))
        val token = field("Bot token", Prefs.tgToken, InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD); root.add(token, top = 0)
        val chat = field("Chat id", Prefs.tgChat); root.add(chat, top = 0)

        root.add(btn("💾 Save settings") {
            Prefs.armed = armed.isChecked; Prefs.autoProtectCars = autoCars.isChecked; Prefs.carLeftAlert = carLeft.isChecked
            Prefs.alertUnknown = alertUnknown.isChecked; Prefs.notifyKnown = notifyKnown.isChecked
            Prefs.motionAlerts = motion.isChecked; Prefs.recordClips = clips.isChecked
            Prefs.dwellSec = (dwell.text.toString().toIntOrNull() ?: 3).coerceIn(1, 120)
            Prefs.cooldownSec = (cooldown.text.toString().toIntOrNull() ?: 60).coerceIn(5, 3600)
            Prefs.clipSec = (clipSec.text.toString().toIntOrNull() ?: 15).coerceIn(5, 120)
            Prefs.faceThreshold = (thr.text.toString().toFloatOrNull() ?: 0.6f).coerceIn(0.3f, 0.95f)
            Prefs.basicThreshold = (bthr.text.toString().toFloatOrNull() ?: 0.88f).coerceIn(0.5f, 0.99f)
            Prefs.minFacePx = (minFace.text.toString().toIntOrNull() ?: 56).coerceIn(24, 400)
            Prefs.intervalMs = (interval.text.toString().toIntOrNull() ?: 500).coerceIn(150, 5000)
            Prefs.analysisWidth = (aw.text.toString().toIntOrNull() ?: 1280).coerceIn(640, 1920)
            Prefs.retentionDays = (keep.text.toString().toIntOrNull() ?: 14).coerceIn(1, 365)
            Prefs.tgToken = token.text.toString().trim(); Prefs.tgChat = chat.text.toString().trim()
            toast("Saved")
        }, top = 18)
        root.add(btn("Send Telegram test") {
            Prefs.tgToken = token.text.toString().trim(); Prefs.tgChat = chat.text.toString().trim()
            Alerts.telegram("✅ TapoGuard test – remote alerts are working", null); toast("Test sent")
        })
    }
}
