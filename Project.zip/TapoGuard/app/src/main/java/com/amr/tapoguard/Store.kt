package com.amr.tapoguard

import android.content.ContentValues
import android.content.Context
import android.content.SharedPreferences
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import org.json.JSONArray
import java.io.File

/** Settings (plain) + camera credentials (AES-256 encrypted with Android Keystore). */
object Prefs {
    private lateinit var sp: SharedPreferences
    private lateinit var secure: SharedPreferences

    fun init(ctx: Context) {
        sp = ctx.getSharedPreferences("settings", Context.MODE_PRIVATE)
        val mk = MasterKey.Builder(ctx).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build()
        secure = EncryptedSharedPreferences.create(
            ctx, "secure_cameras", mk,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
        )
    }

    // ---------- cameras ----------
    fun cameras(): MutableList<CameraConfig> {
        val arr = JSONArray(secure.getString("cameras", "[]") ?: "[]")
        return (0 until arr.length()).map { CameraConfig.fromJson(arr.getJSONObject(it)) }.toMutableList()
    }
    private fun saveCameras(list: List<CameraConfig>) {
        val arr = JSONArray(); list.forEach { arr.put(it.toJson()) }
        secure.edit().putString("cameras", arr.toString()).apply()
    }
    fun camera(id: String): CameraConfig? = cameras().firstOrNull { it.id == id }
    fun upsertCamera(c: CameraConfig) {
        val l = cameras(); val i = l.indexOfFirst { it.id == c.id }
        if (i >= 0) l[i] = c else l.add(c)
        saveCameras(l)
    }
    fun deleteCamera(id: String) = saveCameras(cameras().filter { it.id != id })

    // ---------- settings ----------
    private fun gb(k: String, d: Boolean) = sp.getBoolean(k, d)
    private fun pb(k: String, v: Boolean) = sp.edit().putBoolean(k, v).apply()
    private fun gi(k: String, d: Int) = sp.getInt(k, d)
    private fun pi(k: String, v: Int) = sp.edit().putInt(k, v).apply()
    private fun gf(k: String, d: Float) = sp.getFloat(k, d)
    private fun pf(k: String, v: Float) = sp.edit().putFloat(k, v).apply()
    private fun gs(k: String) = sp.getString(k, "") ?: ""
    private fun ps(k: String, v: String) = sp.edit().putString(k, v).apply()

    var armed: Boolean get() = gb("armed", true); set(v) = pb("armed", v)
    var autoProtectCars: Boolean get() = gb("autoCars", true); set(v) = pb("autoCars", v)
    var recordClips: Boolean get() = gb("recClips", true); set(v) = pb("recClips", v)
    var alertUnknown: Boolean get() = gb("alertUnknown", false); set(v) = pb("alertUnknown", v)
    var notifyKnown: Boolean get() = gb("notifyKnown", false); set(v) = pb("notifyKnown", v)
    var motionAlerts: Boolean get() = gb("motionAlerts", false); set(v) = pb("motionAlerts", v)
    var carLeftAlert: Boolean get() = gb("carLeft", true); set(v) = pb("carLeft", v)

    var faceThreshold: Float get() = gf("faceThr", 0.60f); set(v) = pf("faceThr", v)
    var basicThreshold: Float get() = gf("basicThr", 0.88f); set(v) = pf("basicThr", v)
    var dwellSec: Int get() = gi("dwell", 3); set(v) = pi("dwell", v)
    var cooldownSec: Int get() = gi("cooldown", 60); set(v) = pi("cooldown", v)
    var intervalMs: Int get() = gi("interval", 500); set(v) = pi("interval", v)
    var clipSec: Int get() = gi("clipSec", 15); set(v) = pi("clipSec", v)
    var minFacePx: Int get() = gi("minFace", 56); set(v) = pi("minFace", v)
    var analysisWidth: Int get() = gi("aWidth", 1280); set(v) = pi("aWidth", v)
    var retentionDays: Int get() = gi("retention", 14); set(v) = pi("retention", v)

    var tgToken: String get() = secure.getString("tgToken", "") ?: ""; set(v) = secure.edit().putString("tgToken", v).apply()
    var tgChat: String get() = secure.getString("tgChat", "") ?: ""; set(v) = secure.edit().putString("tgChat", v).apply()
}

class Db(ctx: Context) : SQLiteOpenHelper(ctx, "tapoguard.db", null, 1) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE people(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, role TEXT, authorized INTEGER)")
        db.execSQL("CREATE TABLE faces(id INTEGER PRIMARY KEY AUTOINCREMENT, person_id INTEGER, path TEXT)")
        db.execSQL("CREATE TABLE unknowns(id INTEGER PRIMARY KEY AUTOINCREMENT, path TEXT, first_seen INTEGER, last_seen INTEGER, sightings INTEGER)")
        db.execSQL("CREATE TABLE events(id INTEGER PRIMARY KEY AUTOINCREMENT, ts INTEGER, type TEXT, camera TEXT, message TEXT, image TEXT, clip TEXT, alert INTEGER)")
    }
    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {}

    // ---------- people ----------
    fun people(): List<Person> = readableDatabase.rawQuery(
        "SELECT id,name,role,authorized FROM people ORDER BY name COLLATE NOCASE", null
    ).use { c ->
        val l = mutableListOf<Person>()
        while (c.moveToNext()) l.add(Person(c.getLong(0), c.getString(1) ?: "", c.getString(2) ?: "Guest", c.getInt(3) == 1))
        l
    }
    fun person(id: Long): Person? = people().firstOrNull { it.id == id }
    fun addPerson(name: String, role: String, authorized: Boolean): Long =
        writableDatabase.insert("people", null, ContentValues().apply {
            put("name", name); put("role", role); put("authorized", if (authorized) 1 else 0)
        })
    fun updatePerson(p: Person) {
        writableDatabase.update("people", ContentValues().apply {
            put("name", p.name); put("role", p.role); put("authorized", if (p.authorized) 1 else 0)
        }, "id=?", arrayOf(p.id.toString()))
    }
    fun deletePerson(id: Long) {
        faces(id).forEach { File(it.second).delete() }
        writableDatabase.delete("faces", "person_id=?", arrayOf(id.toString()))
        writableDatabase.delete("people", "id=?", arrayOf(id.toString()))
    }

    // ---------- face samples ----------
    /** (faceId, path) */
    fun faces(personId: Long): List<Pair<Long, String>> = readableDatabase.rawQuery(
        "SELECT id,path FROM faces WHERE person_id=? ORDER BY id", arrayOf(personId.toString())
    ).use { c -> val l = mutableListOf<Pair<Long, String>>(); while (c.moveToNext()) l.add(c.getLong(0) to c.getString(1)); l }

    /** (personId, path) */
    fun allFaces(): List<Pair<Long, String>> = readableDatabase.rawQuery("SELECT person_id,path FROM faces", null)
        .use { c -> val l = mutableListOf<Pair<Long, String>>(); while (c.moveToNext()) l.add(c.getLong(0) to c.getString(1)); l }

    fun addFace(personId: Long, path: String): Long =
        writableDatabase.insert("faces", null, ContentValues().apply { put("person_id", personId); put("path", path) })

    fun deleteFace(faceId: Long) {
        readableDatabase.rawQuery("SELECT path FROM faces WHERE id=?", arrayOf(faceId.toString()))
            .use { c -> if (c.moveToFirst()) File(c.getString(0)).delete() }
        writableDatabase.delete("faces", "id=?", arrayOf(faceId.toString()))
    }

    // ---------- unknown faces ----------
    fun unknowns(): List<UnknownFace> = readableDatabase.rawQuery(
        "SELECT id,path,first_seen,last_seen,sightings FROM unknowns ORDER BY last_seen DESC", null
    ).use { c ->
        val l = mutableListOf<UnknownFace>()
        while (c.moveToNext()) l.add(UnknownFace(c.getLong(0), c.getString(1), c.getLong(2), c.getLong(3), c.getInt(4)))
        l
    }
    fun addUnknown(path: String, ts: Long): Long = writableDatabase.insert("unknowns", null, ContentValues().apply {
        put("path", path); put("first_seen", ts); put("last_seen", ts); put("sightings", 1)
    })
    fun touchUnknown(id: Long, ts: Long) {
        writableDatabase.execSQL("UPDATE unknowns SET last_seen=?, sightings=sightings+1 WHERE id=?", arrayOf<Any>(ts, id))
    }
    fun deleteUnknown(id: Long, deleteFile: Boolean) {
        if (deleteFile) unknowns().firstOrNull { it.id == id }?.let { File(it.path).delete() }
        writableDatabase.delete("unknowns", "id=?", arrayOf(id.toString()))
    }
    fun assignUnknown(u: UnknownFace, personId: Long) {
        addFace(personId, u.path)
        deleteUnknown(u.id, false)
    }

    // ---------- events ----------
    fun addEvent(ts: Long, type: String, camera: String, message: String, image: String?, alert: Boolean): Long =
        writableDatabase.insert("events", null, ContentValues().apply {
            put("ts", ts); put("type", type); put("camera", camera); put("message", message)
            put("image", image); put("alert", if (alert) 1 else 0)
        })
    fun setEventClip(id: Long, clip: String) {
        writableDatabase.update("events", ContentValues().apply { put("clip", clip) }, "id=?", arrayOf(id.toString()))
    }
    fun events(alertsOnly: Boolean, limit: Int = 300): List<EventItem> = readableDatabase.rawQuery(
        "SELECT id,ts,type,camera,message,image,clip,alert FROM events " +
            (if (alertsOnly) "WHERE alert=1 " else "") + "ORDER BY ts DESC LIMIT $limit", null
    ).use { c ->
        val l = mutableListOf<EventItem>()
        while (c.moveToNext()) l.add(
            EventItem(c.getLong(0), c.getLong(1), c.getString(2) ?: "", c.getString(3) ?: "", c.getString(4) ?: "",
                c.getString(5), c.getString(6), c.getInt(7) == 1)
        )
        l
    }
    fun deleteEvent(e: EventItem) {
        e.image?.let { File(it).delete() }; e.clip?.let { File(it).delete() }
        writableDatabase.delete("events", "id=?", arrayOf(e.id.toString()))
    }
    fun clearEvents() { events(false, 100000).forEach { deleteEvent(it) } }
    fun purge(days: Int) {
        val cutoff = System.currentTimeMillis() - days * 86_400_000L
        events(false, 100000).filter { it.ts < cutoff }.forEach { deleteEvent(it) }
    }
}
