package com.amr.tapoguard

import android.annotation.SuppressLint
import android.content.ContentValues
import android.graphics.Bitmap
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.provider.MediaStore
import android.util.Log
import android.view.MotionEvent
import android.view.TextureView
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.VideoSize
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import java.io.File
import kotlin.math.min

@androidx.annotation.OptIn(UnstableApi::class)
class LiveActivity : AppCompatActivity(), Analyzer.Listener {
    private lateinit var cam: CameraConfig
    private lateinit var playerView: PlayerView
    private lateinit var overlay: OverlayView
    private lateinit var status: TextView
    private lateinit var btnRec: Button
    private lateinit var btnAi: Button
    private lateinit var btnArm: Button
    private lateinit var btnZones: Button
    private lateinit var btnClear: Button
    private lateinit var btnMute: Button
    private lateinit var btnDim: Button
    private lateinit var ptzPad: View

    private var player: ExoPlayer? = null
    private var analyzer: Analyzer? = null
    private var recorder: ClipRecorder? = null
    private var onvif: Onvif? = null
    private val ui = Handler(Looper.getMainLooper())

    private var aiOn = true
    private var muted = true
    private var dimmed = false
    private var playing = false
    private var lastAnalysis = 0L
    private var videoW = 1280
    private var videoH = 720
    private var connInfo = "Connecting…"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val c = Prefs.camera(intent.getStringExtra("cam") ?: "")
        if (c == null) { finish(); return }
        cam = c
        setContentView(R.layout.activity_live)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        playerView = findViewById(R.id.playerView)
        overlay = findViewById(R.id.overlay)
        status = findViewById(R.id.status)
        btnRec = findViewById(R.id.btnRec)
        btnAi = findViewById(R.id.btnAi)
        btnArm = findViewById(R.id.btnArm)
        btnZones = findViewById(R.id.btnZones)
        btnClear = findViewById(R.id.btnClearZones)
        btnMute = findViewById(R.id.btnMute)
        btnDim = findViewById(R.id.btnDim)
        ptzPad = findViewById(R.id.ptzPad)

        overlay.zones = cam.zones.toList()
        overlay.onZonesChanged = { z -> cam.zones = z.toMutableList(); Prefs.upsertCamera(cam) }

        findViewById<Button>(R.id.btnSnap).setOnClickListener { snapshot() }
        btnRec.setOnClickListener { if (recorder == null) startRecording(null, null) else stopRecording() }
        btnAi.setOnClickListener {
            aiOn = !aiOn; btnAi.text = if (aiOn) "AI: ON" else "AI: OFF"
            if (!aiOn) { overlay.dets = emptyList(); overlay.protectedAreas = emptyList(); overlay.invalidate() }
        }
        updateArm()
        btnArm.setOnClickListener { Prefs.armed = !Prefs.armed; updateArm() }
        btnZones.setOnClickListener {
            overlay.editMode = !overlay.editMode
            btnZones.text = if (overlay.editMode) "✔ Done" else "🚗 Car zone"
            btnClear.visibility = if (overlay.editMode) View.VISIBLE else View.GONE
        }
        btnClear.setOnClickListener {
            overlay.zones = emptyList(); cam.zones = mutableListOf(); Prefs.upsertCamera(cam); overlay.invalidate()
        }
        findViewById<Button>(R.id.btnPtz).setOnClickListener {
            ptzPad.visibility = if (ptzPad.visibility == View.VISIBLE) View.GONE else View.VISIBLE
        }
        btnMute.setOnClickListener {
            muted = !muted; player?.volume = if (muted) 0f else 1f
            btnMute.text = if (muted) "🔇 Muted" else "🔊 Sound"
        }
        btnDim.setOnClickListener {
            dimmed = !dimmed
            window.attributes = window.attributes.apply {
                screenBrightness = if (dimmed) 0.01f else WindowManager.LayoutParams.BRIGHTNESS_OVERRIDE_NONE
            }
            btnDim.text = if (dimmed) "Bright" else "Dim screen"
        }

        val o = Onvif(cam.ip, cam.user, cam.pass)
        o.onError = { msg -> runOnUiThread { toast("PTZ: $msg") } }
        onvif = o
        bindPtz(R.id.ptzUp, 0f, 0.5f); bindPtz(R.id.ptzDown, 0f, -0.5f)
        bindPtz(R.id.ptzLeft, -0.5f, 0f); bindPtz(R.id.ptzRight, 0.5f, 0f)

        analyzer = Analyzer(cam, this)
    }

    private fun updateArm() { btnArm.text = if (Prefs.armed) "🛡 Armed" else "Disarmed" }

    @SuppressLint("ClickableViewAccessibility")
    private fun bindPtz(id: Int, x: Float, y: Float) {
        findViewById<Button>(id).setOnTouchListener { v, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> onvif?.move(x, y)
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> { onvif?.stop(); v.performClick() }
            }
            true
        }
    }

    override fun onStart() {
        super.onStart()
        if (!::cam.isInitialized) return
        startPlayer()
        ui.post(tick)
    }

    override fun onStop() {
        super.onStop()
        ui.removeCallbacksAndMessages(null)
        stopRecording()
        player?.release(); player = null; playing = false
    }

    override fun onDestroy() {
        super.onDestroy()
        analyzer?.release()
        onvif?.shutdown()
    }

    private fun startPlayer() {
        val p = ExoPlayer.Builder(this)
            .setLoadControl(DefaultLoadControl.Builder().setBufferDurationsMs(1000, 3000, 500, 500).build())
            .build()
        p.volume = if (muted) 0f else 1f
        p.addListener(object : Player.Listener {
            override fun onPlaybackStateChanged(playbackState: Int) {
                playing = playbackState == Player.STATE_READY
                if (playing) { connInfo = "Live • ${cam.name}"; status.text = connInfo }
            }
            override fun onPlayerError(error: PlaybackException) {
                playing = false
                connInfo = "Stream error (${error.errorCodeName}). Check IP / camera account. Retrying in 5 s…"
                status.text = connInfo
                ui.postDelayed({
                    if (player === p) { p.setMediaSource(rtspSource(cam.rtspUrl())); p.prepare(); p.playWhenReady = true }
                }, 5000)
            }
            override fun onVideoSizeChanged(videoSize: VideoSize) {
                if (videoSize.width > 0 && videoSize.height > 0) {
                    videoW = videoSize.width; videoH = videoSize.height
                    overlay.videoAspect = videoW.toFloat() / videoH; overlay.invalidate()
                }
            }
        })
        p.setMediaSource(rtspSource(cam.rtspUrl()))
        p.prepare()
        p.playWhenReady = true
        playerView.player = p
        player = p
    }

    private val tick = object : Runnable {
        override fun run() {
            try {
                val now = SystemClock.elapsedRealtime()
                val rec = recorder?.isRecording == true
                val a = analyzer
                val needAi = aiOn && a != null && !a.busy && now - lastAnalysis >= Prefs.intervalMs
                if (playing && (needAi || rec)) {
                    val bmp = grab(Prefs.analysisWidth)
                    if (bmp != null) {
                        if (rec) recorder?.submit(bmp)
                        if (needAi) { lastAnalysis = now; a?.submit(bmp) }
                    }
                }
            } catch (e: Exception) { Log.w(TAG, "tick", e) }
            ui.postDelayed(this, 125)
        }
    }

    private fun grab(maxW: Int): Bitmap? {
        val tv = playerView.videoSurfaceView as? TextureView ?: return null
        if (!tv.isAvailable) return null
        val w = min(maxW, videoW)
        val h = (w.toFloat() * videoH / videoW).toInt()
        return tv.getBitmap(w, h)
    }

    // ---------------------------------------------------------------- Analyzer.Listener
    override fun onResult(r: AnalysisResult) {
        runOnUiThread {
            if (!aiOn) return@runOnUiThread
            overlay.dets = r.dets; overlay.protectedAreas = r.protectedAreas; overlay.invalidate()
            status.text = "$connInfo\n${r.status}"
        }
    }

    override fun onAlert(eventId: Long, title: String) {
        runOnUiThread {
            toast(title)
            if (Prefs.recordClips && recorder == null) startRecording(eventId, Prefs.clipSec)
        }
    }

    // ---------------------------------------------------------------- snapshot / recording
    private fun snapshot() {
        val bmp = grab(videoW) ?: run { toast("No video yet"); return }
        Thread {
            try {
                val values = ContentValues().apply {
                    put(MediaStore.Images.Media.DISPLAY_NAME, "TapoGuard_${fileStamp()}.jpg")
                    put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
                    put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/TapoGuard")
                }
                val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
                if (uri != null) contentResolver.openOutputStream(uri)?.use { bmp.compress(Bitmap.CompressFormat.JPEG, 92, it) }
                runOnUiThread { toast("Snapshot saved to Pictures/TapoGuard") }
            } catch (e: Exception) { runOnUiThread { toast("Snapshot failed: ${e.message}") } }
        }.start()
    }

    private fun startRecording(eventId: Long?, seconds: Int?) {
        if (!playing) { toast("No video yet"); return }
        val dir = getExternalFilesDir(Environment.DIRECTORY_MOVIES) ?: filesDir
        val f = File(dir, "clip_${fileStamp()}.mp4")
        val r = ClipRecorder(f)
        if (!r.start()) { toast("Recorder not supported on this device"); return }
        val camName = cam.name
        r.onFinished = { file ->
            if (file != null) {
                if (eventId != null) App.db.setEventClip(eventId, file.absolutePath)
                else {
                    val evId = App.db.addEvent(System.currentTimeMillis(), "RECORDING", camName, "Manual recording", null, false)
                    App.db.setEventClip(evId, file.absolutePath)
                }
            }
        }
        recorder = r
        btnRec.text = "■ Stop (REC)"
        if (seconds != null) ui.postDelayed({ if (recorder === r) stopRecording() }, seconds * 1000L)
    }

    private fun stopRecording() {
        val r = recorder ?: return
        recorder = null
        r.stop()
        if (::btnRec.isInitialized) btnRec.text = "● Rec"
    }
}
