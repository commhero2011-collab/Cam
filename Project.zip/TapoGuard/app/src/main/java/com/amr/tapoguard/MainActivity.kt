package com.amr.tapoguard

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.widget.LinearLayout
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.materialswitch.MaterialSwitch

class MainActivity : AppCompatActivity() {
    private val notifPerm = registerForActivityResult(ActivityResultContracts.RequestPermission()) { }
    private lateinit var root: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        root = vbox()
        setScroll(root)
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) notifPerm.launch(Manifest.permission.POST_NOTIFICATIONS)
    }

    override fun onResume() { super.onResume(); render() }

    private fun go(cls: Class<*>) = startActivity(Intent(this, cls))

    private fun render() {
        root.removeAllViews()
        root.add(label("TapoGuard", 26f, true), top = 0)
        root.add(label("Tapo C200 surveillance • face recognition • car guard", 13f, color = Color.GRAY), top = 0)

        val engine = label("Loading AI engines…", 13f)
        val arm = MaterialSwitch(this).apply {
            text = "Alerts armed"; isChecked = Prefs.armed
            setOnCheckedChangeListener { _, v -> Prefs.armed = v }
        }
        root.add(card(arm, engine))
        Thread {
            val f = App.faces; val o = App.objects
            val s = "Face recognition: ${f.modelInfo}\n" +
                "Person/car detection: ${if (o.available) "ready (EfficientDet-Lite0)" else "MISSING – ${o.error}"}\n" +
                "Known people: ${f.people.size}"
            runOnUiThread { engine.text = s }
        }.start()

        root.add(label("Cameras", 18f, true), top = 16)
        val cams = Prefs.cameras()
        if (cams.isEmpty()) root.add(label("No camera yet. Tap “Add camera” and enter your Tapo C200 IP and Camera Account.", 14f))
        for (c in cams) {
            val row = hbox()
            row.addWeighted(btn("▶ Live + AI") { startActivity(Intent(this, LiveActivity::class.java).putExtra("cam", c.id)) })
            row.addWeighted(btn("Edit") { startActivity(Intent(this, CameraEditActivity::class.java).putExtra("cam", c.id)) })
            root.add(card(
                label(c.name, 17f, true),
                label("${c.ip} • ${if (c.stream == "stream1") "HD" else "SD"} • car zones: ${c.zones.size}", 13f, color = Color.GRAY),
                row
            ))
        }
        root.add(btn("+ Add camera") { go(CameraEditActivity::class.java) })

        root.add(label("Tools", 18f, true), top = 16)
        root.add(btn("🖥  Multi-camera view") { go(GridActivity::class.java) })
        root.add(btn("👤  People & face library") { go(PeopleActivity::class.java) })
        root.add(btn("❓  Unknown faces (label them)") { go(UnknownActivity::class.java) })
        root.add(btn("🔔  Events, snapshots & clips") { go(EventsActivity::class.java) })
        root.add(btn("⚙  Settings & remote alerts") { go(SettingsActivity::class.java) })
    }
}
