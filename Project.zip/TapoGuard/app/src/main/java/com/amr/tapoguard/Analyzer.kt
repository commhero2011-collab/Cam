package com.amr.tapoguard

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.os.Handler
import android.os.HandlerThread
import android.os.SystemClock
import android.util.Log
import java.io.File
import java.io.FileOutputStream
import kotlin.math.abs

class AnalysisResult(val dets: List<Det>, val protectedAreas: List<RectF>, val status: String)

/**
 * Runs the AI pipeline on frames from the live stream:
 * motion → person/vehicle detection → face detection → face recognition → tracking → car-guard rules → events/alerts.
 */
class Analyzer(private val cam: CameraConfig, private val listener: Listener) {

    interface Listener {
        fun onResult(r: AnalysisResult)
        fun onAlert(eventId: Long, title: String)
    }

    private class Track(val id: Int, var box: RectF, val first: Long) {
        var last = first
        var personId: Long? = null
        var name: String? = null
        var role: String? = null
        var authorized = false
        var unknownId: Long? = null
        var nearSince: Long? = null
        var carAlerted = false
    }

    private class Car(var box: RectF, val first: Long) {
        var last = first
        var parked = false
    }

    private class Pending(
        val type: String, val title: String, val msg: String,
        val alert: Boolean, val high: Boolean = false, val key: String = type
    )

    private val thread = HandlerThread("analyzer").apply { start() }
    private val handler = Handler(thread.looper)
    @Volatile var busy = false
        private set

    private val tracks = mutableListOf<Track>()
    private val cars = mutableListOf<Car>()
    private val pending = mutableListOf<Pending>()
    private val lastEvent = HashMap<String, Long>()
    private var nextId = 1
    private var prevGray: IntArray? = null
    private val eventsDir = File(App.instance.filesDir, "events").apply { mkdirs() }

    fun submit(bmp: Bitmap) {
        if (busy) return
        busy = true
        handler.post {
            try { process(bmp) } catch (t: Throwable) { Log.e(TAG, "analysis failed", t) } finally { busy = false }
        }
    }

    fun release() {
        handler.removeCallbacksAndMessages(null)
        thread.quitSafely()
    }

    private fun process(bmp: Bitmap) {
        val t0 = SystemClock.elapsedRealtime()
        val now = System.currentTimeMillis()
        val faces = App.faces
        val objs = App.objects
        val w = bmp.width.toFloat(); val h = bmp.height.toFloat()

        // 1) motion
        val motion = motionScore(bmp)

        // 2) persons + vehicles
        val all = if (objs.available) objs.detect(bmp) else emptyList()
        val persons = all.filter { it.kind == "person" }.toMutableList()
        val vehicles = all.filter { it.kind == "vehicle" }

        // 3) faces → identity
        val faceDets = mutableListOf<Det>()
        if (persons.isNotEmpty() || !objs.available || motion > 0.01f) {
            for (f in faces.detect(bmp)) {
                val r = f.boundingBox
                val nb = RectF(r.left / w, r.top / h, r.right / w, r.bottom / h)
                var host = persons.firstOrNull { it.box.contains(nb.centerX(), nb.centerY()) }
                if (host == null) {
                    host = Det("person", "person", 0.5f, RectF(
                        (nb.left - nb.width()).coerceAtLeast(0f), nb.top,
                        (nb.right + nb.width()).coerceAtMost(1f), (nb.bottom + nb.height() * 5f).coerceAtMost(1f)
                    ))
                    persons.add(host)
                }
                val fd = Det("face", "face", 1f, nb).apply { color = Det.WHITE }
                faceDets.add(fd)
                val thumb = faces.crop(bmp, r) ?: continue
                val emb = faces.embed(thumb)
                val pid = faces.match(emb)
                if (pid != null) {
                    host.personId = pid
                    fd.name = faces.people[pid]?.name
                } else {
                    val frontal = abs(f.headEulerAngleY) < 30f && abs(f.headEulerAngleZ) < 30f
                    if (r.width() >= Prefs.minFacePx && frontal) {
                        host.unknownThumb = thumb; host.unknownEmb = emb
                    }
                }
            }
        }

        // 4) tracking + identity bookkeeping
        updateTracks(persons, now)

        // 5) parked-car memory
        updateCars(vehicles, now)

        // 6) car guard rule
        val areas = ArrayList<RectF>(cam.zones.toList())
        if (Prefs.autoProtectCars) cars.filter { it.parked }.forEach { areas.add(it.box) }
        checkCarInteraction(areas, now)

        // 7) motion alerts (optional)
        if (Prefs.motionAlerts && motion > 0.03f) {
            pending.add(Pending("MOTION", "Motion detected", "Motion ${(motion * 100).toInt()}% of the image", true))
        }

        val dets = ArrayList<Det>().apply { addAll(vehicles); addAll(persons); addAll(faceDets) }
        flush(bmp, dets, areas, now)

        val ms = SystemClock.elapsedRealtime() - t0
        val status = buildString {
            append(if (Prefs.armed) "● ARMED" else "○ disarmed")
            append("  •  persons ${persons.size}  •  vehicles ${vehicles.size}  •  protected ${areas.size}")
            append("  •  motion ${(motion * 100).toInt()}%  •  AI ${ms}ms")
            if (!objs.available) append("\n⚠ object model missing – car detection only via drawn zones")
            if (!faces.usingModel) append("\n⚠ NO face recognition model: nobody is auto-authorised")
        }
        listener.onResult(AnalysisResult(dets, areas, status))
    }

    // ---------------------------------------------------------------- tracking
    private fun updateTracks(persons: List<Det>, now: Long) {
        val used = HashSet<Track>()
        for (d in persons) {
            var best: Track? = null
            var bestIou = 0.25f
            for (t in tracks) {
                if (t in used) continue
                val v = iou(t.box, d.box)
                if (v > bestIou) { bestIou = v; best = t }
            }
            val t = best ?: Track(nextId++, RectF(d.box), now).also { tracks.add(it) }
            used.add(t)
            t.box = RectF(d.box); t.last = now

            val pid = d.personId
            val uEmb = d.unknownEmb
            val uThumb = d.unknownThumb
            if (pid != null && t.personId != pid) {
                val p = App.faces.people[pid]
                t.personId = pid; t.name = p?.name; t.role = p?.role; t.authorized = p?.authorized == true
                if (p?.role == "Blocked") {
                    pending.add(Pending("BLOCKED_PERSON", "⛔ Blocked person detected", "${p.name} was recognised", true, true, "blocked_$pid"))
                } else {
                    pending.add(Pending("KNOWN_PERSON", "Person recognised", "${t.name} (${t.role}) is here", Prefs.notifyKnown, false, "known_$pid"))
                }
            } else if (uEmb != null && uThumb != null && t.personId == null && t.unknownId == null) {
                val existing = App.faces.matchUnknown(uEmb)
                val uid = if (existing != null) { App.db.touchUnknown(existing, now); existing }
                else App.faces.addUnknown(uThumb, uEmb, now)
                t.unknownId = uid
                pending.add(Pending("UNKNOWN_PERSON", "Unknown person", "Unknown face #$uid seen – label it in 'Unknown faces'", Prefs.alertUnknown, false, "unknown_$uid"))
            }

            d.name = t.name ?: t.unknownId?.let { "Unknown #$it" }
            d.color = when {
                t.role == "Blocked" -> Det.MAGENTA
                t.personId != null && t.authorized -> Det.GREEN
                t.personId != null -> Det.BLUE
                t.unknownId != null -> Det.RED
                else -> Det.AMBER
            }
        }
        tracks.removeAll { now - it.last > 4000 }
    }

    private fun updateCars(vehicles: List<Det>, now: Long) {
        for (v in vehicles) {
            val c = cars.firstOrNull { iou(it.box, v.box) > 0.4f }
            if (c != null) {
                c.box = RectF(v.box); c.last = now
                if (!c.parked && now - c.first > 15_000) {
                    c.parked = true
                    pending.add(Pending("CAR_PARKED", "Car parked", "A ${v.label} is parked and now protected", false, false, "parked"))
                }
            } else cars.add(Car(RectF(v.box), now))
        }
        val gone = cars.filter { now - it.last > 45_000 }
        if (gone.any { it.parked } && vehicles.isEmpty() && Prefs.carLeftAlert) {
            pending.add(Pending("CAR_LEFT", "🚗 Protected car left", "A parked car is no longer visible", Prefs.carLeftAlert, true, "carleft"))
        }
        cars.removeAll(gone.toSet())
    }

    private fun checkCarInteraction(areas: List<RectF>, now: Long) {
        if (areas.isEmpty()) return
        val dwell = Prefs.dwellSec * 1000L
        for (t in tracks) {
            if (t.last != now) continue
            if (nearAny(t.box, areas)) {
                val since = t.nearSince ?: now.also { t.nearSince = it }
                if (t.carAlerted || now - since < dwell) continue
                // give the camera a little extra time to see the face before alerting as "unidentified"
                if (t.personId == null && t.unknownId == null && now - since < dwell * 2) continue
                t.carAlerted = true
                if (t.personId != null && t.authorized) {
                    pending.add(Pending("CAR_AUTHORIZED", "Authorised person at car", "${t.name} is at the car", false, false, "auth_${t.personId}"))
                } else {
                    val who = t.name ?: t.unknownId?.let { "Unknown person #$it" } ?: "Unidentified person (face not visible)"
                    pending.add(Pending("CAR_INTERACTION", "⚠ Someone is at your car",
                        "$who has been at the car for ${(now - since) / 1000}s", true, true, "car"))
                }
            } else {
                t.nearSince = null; t.carAlerted = false
            }
        }
    }

    // ---------------------------------------------------------------- events
    private fun flush(bmp: Bitmap, dets: List<Det>, areas: List<RectF>, now: Long) {
        if (pending.isEmpty()) return
        var snap: Bitmap? = null
        for (p in pending) {
            val cd = if (p.key.startsWith("known_") || p.key.startsWith("unknown_") || p.key.startsWith("auth_")) 600_000L
            else Prefs.cooldownSec * 1000L
            if (now - (lastEvent[p.key] ?: 0L) < cd) continue
            if (p.type == "MOTION" && !p.alert) continue
            lastEvent[p.key] = now
            val s = snap ?: annotate(bmp, dets, areas).also { snap = it }
            val f = File(eventsDir, "evt_${now}_${p.type}.jpg")
            try { FileOutputStream(f).use { s.compress(Bitmap.CompressFormat.JPEG, 85, it) } } catch (e: Exception) { Log.w(TAG, e) }
            val alert = p.alert && Prefs.armed
            val id = App.db.addEvent(now, p.type, cam.name, "${p.title}: ${p.msg}", f.absolutePath, alert)
            if (alert) {
                Alerts.notify(p.title, "${p.msg} • ${cam.name}", s, p.high)
                Alerts.telegram("${p.title}\n${p.msg}\nCamera: ${cam.name}\n${timeStr(now)}", s)
                listener.onAlert(id, p.title)
            }
        }
        pending.clear()
    }

    private fun annotate(bmp: Bitmap, dets: List<Det>, areas: List<RectF>): Bitmap {
        val out = bmp.copy(Bitmap.Config.ARGB_8888, true)
        val c = Canvas(out)
        val w = out.width.toFloat(); val h = out.height.toFloat()
        val box = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 4f }
        val txt = Paint(Paint.ANTI_ALIAS_FLAG).apply { textSize = 26f; isFakeBoldText = true; color = Color.BLACK }
        val bg = Paint()
        box.color = Color.YELLOW
        for (a in areas) c.drawRect(a.left * w, a.top * h, a.right * w, a.bottom * h, box)
        for (d in dets) {
            box.color = d.color
            val l = d.box.left * w; val t = d.box.top * h
            c.drawRect(l, t, d.box.right * w, d.box.bottom * h, box)
            val s = d.name ?: if (d.kind == "face") "" else d.label
            if (s.isNotEmpty()) {
                val top = (t - 34f).coerceAtLeast(0f)
                bg.color = d.color
                c.drawRect(l, top, l + txt.measureText(s) + 12f, top + 34f, bg)
                c.drawText(s, l + 6f, top + 26f, txt)
            }
        }
        txt.color = Color.WHITE
        c.drawText("${cam.name}  ${timeStr(System.currentTimeMillis())}", 12f, h - 12f, txt)
        return out
    }

    // ---------------------------------------------------------------- helpers
    private fun motionScore(b: Bitmap): Float {
        val sw = 64; val sh = 36
        val s = Bitmap.createScaledBitmap(b, sw, sh, true)
        val px = IntArray(sw * sh); s.getPixels(px, 0, sw, 0, 0, sw, sh)
        val g = IntArray(px.size) { val p = px[it]; (((p shr 16) and 255) * 3 + ((p shr 8) and 255) * 6 + (p and 255)) / 10 }
        val prev = prevGray
        prevGray = g
        if (prev == null) return 0f
        var changed = 0
        for (i in g.indices) if (abs(g[i] - prev[i]) > 25) changed++
        return changed.toFloat() / g.size
    }

    private fun iou(a: RectF, b: RectF): Float {
        val i = RectF()
        if (!i.setIntersect(a, b)) return 0f
        val inter = i.width() * i.height()
        val union = a.width() * a.height() + b.width() * b.height() - inter
        return if (union <= 0f) 0f else inter / union
    }

    private fun nearAny(p: RectF, areas: List<RectF>): Boolean {
        val pa = (p.width() * p.height()).coerceAtLeast(1e-6f)
        for (a in areas) {
            val e = RectF(a.left - a.width() * 0.08f, a.top - a.height() * 0.08f, a.right + a.width() * 0.08f, a.bottom + a.height() * 0.08f)
            val i = RectF()
            if (i.setIntersect(p, e) && (i.width() * i.height()) / pa >= 0.2f) return true
        }
        return false
    }
}
