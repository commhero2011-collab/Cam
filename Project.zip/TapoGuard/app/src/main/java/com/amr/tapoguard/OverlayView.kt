package com.amr.tapoguard

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.DashPathEffect
import android.graphics.Paint
import android.graphics.RectF
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import kotlin.math.max
import kotlin.math.min

/** Draws AI detections and car zones over the video; in edit mode lets the user draw car zones. */
class OverlayView @JvmOverloads constructor(ctx: Context, attrs: AttributeSet? = null) : View(ctx, attrs) {
    var dets: List<Det> = emptyList()
    var protectedAreas: List<RectF> = emptyList()
    var zones: List<RectF> = emptyList()
    var videoAspect = 16f / 9f
    var editMode = false
        set(v) { field = v; invalidate() }
    var onZonesChanged: ((List<RectF>) -> Unit)? = null

    private var drag: RectF? = null
    private var sx = 0f
    private var sy = 0f
    private val box = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 5f }
    private val prot = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 3f; color = Color.YELLOW }
    private val zoneP = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeWidth = 4f; color = Color.YELLOW
        pathEffect = DashPathEffect(floatArrayOf(18f, 10f), 0f)
    }
    private val fill = Paint().apply { color = 0x33FFEB3B }
    private val txt = Paint(Paint.ANTI_ALIAS_FLAG).apply { textSize = 32f; isFakeBoldText = true; color = Color.BLACK }
    private val txtBg = Paint()

    private fun content(): RectF {
        val vw = width.toFloat(); val vh = height.toFloat()
        if (vw <= 0f || vh <= 0f) return RectF(0f, 0f, 1f, 1f)
        return if (vw / vh > videoAspect) {
            val w = vh * videoAspect; RectF((vw - w) / 2f, 0f, (vw + w) / 2f, vh)
        } else {
            val h = vw / videoAspect; RectF(0f, (vh - h) / 2f, vw, (vh + h) / 2f)
        }
    }

    private fun map(r: RectF, c: RectF) = RectF(
        c.left + r.left * c.width(), c.top + r.top * c.height(),
        c.left + r.right * c.width(), c.top + r.bottom * c.height()
    )

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val c = content()
        for (z in zones) {
            val m = map(z, c)
            canvas.drawRect(m, fill); canvas.drawRect(m, zoneP)
            tag(canvas, "CAR ZONE", m.left, m.top, Color.YELLOW)
        }
        for (p in protectedAreas) if (p !in zones) canvas.drawRect(map(p, c), prot)
        for (d in dets) {
            box.color = d.color
            val m = map(d.box, c)
            canvas.drawRect(m, box)
            val s = when (d.kind) {
                "vehicle" -> "${d.label} ${(d.score * 100).toInt()}%"
                "face" -> d.name ?: ""
                else -> d.name ?: "person"
            }
            if (s.isNotEmpty()) tag(canvas, s, m.left, m.top, d.color)
        }
        drag?.let { canvas.drawRect(it, zoneP) }
        if (editMode) tag(canvas, "Drag a rectangle around your car", c.left + 20f, c.top + 110f, Color.YELLOW)
    }

    private fun tag(cv: Canvas, s: String, x: Float, y: Float, color: Int) {
        val top = (y - 40f).coerceAtLeast(0f)
        txtBg.color = color
        cv.drawRect(x, top, x + txt.measureText(s) + 16f, top + 40f, txtBg)
        cv.drawText(s, x + 8f, top + 30f, txt)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (!editMode) return false
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> { sx = e.x; sy = e.y; drag = RectF(sx, sy, sx, sy) }
            MotionEvent.ACTION_MOVE -> {
                drag = RectF(min(sx, e.x), min(sy, e.y), max(sx, e.x), max(sy, e.y)); invalidate()
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                val d = drag; drag = null
                val c = content()
                if (d != null && d.width() > 40f && d.height() > 40f) {
                    val n = RectF(
                        ((d.left - c.left) / c.width()).coerceIn(0f, 1f), ((d.top - c.top) / c.height()).coerceIn(0f, 1f),
                        ((d.right - c.left) / c.width()).coerceIn(0f, 1f), ((d.bottom - c.top) / c.height()).coerceIn(0f, 1f)
                    )
                    zones = zones + n
                    onZonesChanged?.invoke(zones)
                }
                invalidate(); performClick()
            }
        }
        return true
    }

    override fun performClick(): Boolean = super.performClick()
}
