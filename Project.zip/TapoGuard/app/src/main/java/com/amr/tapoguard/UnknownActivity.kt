package com.amr.tapoguard

import android.graphics.Color
import android.os.Bundle
import android.widget.GridLayout
import android.widget.ImageView
import android.widget.LinearLayout
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Faces the camera saw but could not match – label them to link them to a character. */
class UnknownActivity : AppCompatActivity() {
    private lateinit var root: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        title = "Unknown faces"
        root = vbox(); setScroll(root)
    }

    override fun onResume() { super.onResume(); render() }

    private fun reloadThenRender() {
        Thread { App.faces.reloadGallery(); runOnUiThread { render() } }.start()
    }

    private fun render() {
        root.removeAllViews()
        val list = App.db.unknowns()
        root.add(label("${list.size} unknown face(s). Tap a face to name it, add it to an existing person, or delete it. " +
            "Similar sightings are grouped automatically.", 13f, color = Color.GRAY), top = 0)
        if (list.isNotEmpty()) root.add(btn("Delete all unknown faces") {
            MaterialAlertDialogBuilder(this).setTitle("Delete all ${list.size} unknown faces?")
                .setPositiveButton("Delete") { _, _ -> list.forEach { App.db.deleteUnknown(it.id, true) }; reloadThenRender() }
                .setNegativeButton("Cancel", null).show()
        })
        val fmt = SimpleDateFormat("dd MMM HH:mm", Locale.US)
        val grid = GridLayout(this).apply { columnCount = 3 }
        for (u in list) {
            val cell = vbox(4)
            val iv = ImageView(this).apply { scaleType = ImageView.ScaleType.CENTER_CROP; loadThumb(u.path, 1)?.let { setImageBitmap(it) } }
            cell.addView(iv, LinearLayout.LayoutParams(dp(100), dp(100)))
            cell.add(label("#${u.id} • ${u.sightings}×\n${fmt.format(Date(u.lastSeen))}", 11f), top = 2)
            cell.setOnClickListener { actions(u) }
            grid.addView(cell)
        }
        root.add(grid)
    }

    private fun actions(u: UnknownFace) {
        MaterialAlertDialogBuilder(this).setTitle("Unknown #${u.id}")
            .setItems(arrayOf("Create new person from this face", "Add to existing person", "Delete")) { _, which ->
                when (which) {
                    0 -> createPerson(u)
                    1 -> assignExisting(u)
                    else -> { App.db.deleteUnknown(u.id, true); reloadThenRender() }
                }
            }.show()
    }

    private fun createPerson(u: UnknownFace) {
        val name = field("Name")
        val auth = check("Allowed to touch / use the car", false)
        val box = vbox(16); box.add(name, top = 0); box.add(auth)
        MaterialAlertDialogBuilder(this).setTitle("New person").setView(box)
            .setPositiveButton("Create") { _, _ ->
                val n = name.text.toString().trim()
                if (n.isNotEmpty()) {
                    val pid = App.db.addPerson(n, if (auth.isChecked) "Family" else "Guest", auth.isChecked)
                    App.db.assignUnknown(u, pid)
                    toast("$n added"); reloadThenRender()
                }
            }.setNegativeButton("Cancel", null).show()
    }

    private fun assignExisting(u: UnknownFace) {
        val people = App.db.people()
        if (people.isEmpty()) { toast("No people yet – create one"); return }
        MaterialAlertDialogBuilder(this).setTitle("Add face to…")
            .setItems(people.map { it.name }.toTypedArray()) { _, i ->
                App.db.assignUnknown(u, people[i].id)
                toast("Linked to ${people[i].name}"); reloadThenRender()
            }.show()
    }
}
