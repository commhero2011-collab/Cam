package com.amr.tapoguard

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Rect
import android.util.Log
import com.google.android.gms.tasks.Tasks
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.face.Face
import com.google.mlkit.vision.face.FaceDetection
import com.google.mlkit.vision.face.FaceDetector
import com.google.mlkit.vision.face.FaceDetectorOptions
import org.tensorflow.lite.DataType
import org.tensorflow.lite.Interpreter
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.channels.FileChannel
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.TimeUnit
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/**
 * Face detection (ML Kit, on-device) + face recognition (TFLite embedding model such as MobileFaceNet).
 * Without a model it falls back to a BASIC pixel-signature matcher (works only for close, frontal faces).
 */
class FaceEngine(private val ctx: Context) {

    private val detector: FaceDetector = FaceDetection.getClient(
        FaceDetectorOptions.Builder()
            .setPerformanceMode(FaceDetectorOptions.PERFORMANCE_MODE_ACCURATE)
            .setMinFaceSize(0.04f)
            .build()
    )

    private var interpreter: Interpreter? = null
    private var inW = 112
    private var inH = 112
    private var outDim = 0
    private var inBytes = 0
    private var outBytes = 0
    private var quantIn = false

    var modelInfo: String = ""
        private set
    val usingModel: Boolean get() = interpreter != null

    @Volatile var people: Map<Long, Person> = emptyMap()
        private set

    private class Entry(val personId: Long, val emb: FloatArray)
    @Volatile private var gallery: List<Entry> = emptyList()
    private val unknownGallery = CopyOnWriteArrayList<Pair<Long, FloatArray>>()

    init { loadModel() }

    private fun hasAsset(name: String) = try { ctx.assets.openFd(name).close(); true } catch (e: Exception) { false }

    private fun loadAsset(name: String): ByteBuffer {
        val fd = ctx.assets.openFd(name)
        return fd.use { descriptor ->
            FileInputStream(descriptor.fileDescriptor).use { stream ->
                stream.channel.map(FileChannel.MapMode.READ_ONLY, descriptor.startOffset, descriptor.declaredLength)
            }
        }
    }

    @Synchronized
    fun loadModel() {
        interpreter?.close(); interpreter = null
        val opts = Interpreter.Options().setNumThreads(2)
        val imported = File(ctx.filesDir, "face_model.tflite")
        var source = ""
        var err: String? = null
        val itp: Interpreter? = try {
            when {
                imported.exists() -> { source = "imported"; Interpreter(imported, opts) }
                hasAsset("face.tflite") -> { source = "bundled"; Interpreter(loadAsset("face.tflite"), opts) }
                else -> null
            }
        } catch (e: Throwable) { Log.e(TAG, "face model", e); err = e.message; null }

        if (itp != null) {
            val inT = itp.getInputTensor(0)
            val shape = inT.shape()
            val outT = itp.getOutputTensor(0)
            if (shape.size == 4 && shape[3] == 3 && outT.dataType() == DataType.FLOAT32) {
                inH = shape[1]; inW = shape[2]
                quantIn = inT.dataType() == DataType.UINT8
                inBytes = inT.numBytes(); outBytes = outT.numBytes()
                val os = outT.shape(); outDim = os[os.size - 1]
                interpreter = itp
                modelInfo = "Deep face model ($source, ${inW}x${inH} → ${outDim}-d embedding)"
                return
            }
            itp.close()
            err = "unsupported model shape ${shape.contentToString()}"
        }
        modelInfo = if (err != null) "BASIC mode – face model error: $err"
        else "BASIC mode (no face model) – import a MobileFaceNet .tflite in Settings for reliable recognition"
    }

    fun threshold(): Float = if (usingModel) Prefs.faceThreshold else Prefs.basicThreshold

    fun detect(bmp: Bitmap): List<Face> = try {
        Tasks.await(detector.process(InputImage.fromBitmap(bmp, 0)), 5, TimeUnit.SECONDS)
    } catch (e: Exception) { emptyList() }

    /** Square crop around the face, resized to size x size. */
    fun crop(bmp: Bitmap, r: Rect, size: Int = 160): Bitmap? {
        val half = max(r.width(), r.height()) * 0.54f
        val cx = r.exactCenterX(); val cy = r.exactCenterY()
        val l = max(0, (cx - half).toInt()); val t = max(0, (cy - half).toInt())
        val rr = min(bmp.width, (cx + half).toInt()); val b = min(bmp.height, (cy + half).toInt())
        if (rr - l < 20 || b - t < 20) return null
        return Bitmap.createScaledBitmap(Bitmap.createBitmap(bmp, l, t, rr - l, b - t), size, size, true)
    }

    fun extractFaces(bmp: Bitmap): List<Bitmap> =
        detect(bmp).sortedByDescending { it.boundingBox.width() * it.boundingBox.height() }
            .mapNotNull { crop(bmp, it.boundingBox) }

    @Synchronized
    fun embed(face: Bitmap): FloatArray {
        val itp = interpreter ?: return basicEmbed(face)
        val s = Bitmap.createScaledBitmap(face, inW, inH, true)
        val px = IntArray(inW * inH)
        s.getPixels(px, 0, inW, 0, 0, inW, inH)
        val input = ByteBuffer.allocateDirect(inBytes).order(ByteOrder.nativeOrder())
        for (p in px) {
            val r = (p shr 16) and 0xFF; val g = (p shr 8) and 0xFF; val b = p and 0xFF
            if (quantIn) {
                input.put(r.toByte()); input.put(g.toByte()); input.put(b.toByte())
            } else {
                input.putFloat((r - 127.5f) / 128f); input.putFloat((g - 127.5f) / 128f); input.putFloat((b - 127.5f) / 128f)
            }
        }
        input.rewind()
        val out = ByteBuffer.allocateDirect(outBytes).order(ByteOrder.nativeOrder())
        itp.run(input, out)
        out.rewind()
        return l2(FloatArray(outDim) { out.float })
    }

    private fun basicEmbed(face: Bitmap): FloatArray {
        val n = 32
        val s = Bitmap.createScaledBitmap(face, n, n, true)
        val px = IntArray(n * n); s.getPixels(px, 0, n, 0, 0, n, n)
        val v = FloatArray(n * n) {
            val p = px[it]
            ((p shr 16) and 255) * 0.299f + ((p shr 8) and 255) * 0.587f + (p and 255) * 0.114f
        }
        val mean = v.average().toFloat()
        var sd = 0f
        for (x in v) sd += (x - mean) * (x - mean)
        sd = sqrt(sd / v.size).coerceAtLeast(1f)
        for (i in v.indices) v[i] = (v[i] - mean) / sd
        return l2(v)
    }

    private fun l2(v: FloatArray): FloatArray {
        var s = 0f
        for (x in v) s += x * x
        val n = sqrt(s).coerceAtLeast(1e-6f)
        for (i in v.indices) v[i] = v[i] / n
        return v
    }

    private fun cos(a: FloatArray, b: FloatArray): Float {
        if (a.size != b.size) return -1f
        var s = 0f
        for (i in a.indices) s += a[i] * b[i]
        return s
    }

    /** Returns the matching person id or null. */
    fun match(emb: FloatArray): Long? {
        // A pixel signature is not biometric recognition. Never authorise a person with it.
        if (!usingModel) return null
        var best = threshold(); var id: Long? = null
        for (e in gallery) { val s = cos(e.emb, emb); if (s > best) { best = s; id = e.personId } }
        return id
    }

    fun matchUnknown(emb: FloatArray): Long? {
        if (!usingModel) return null
        var best = threshold(); var id: Long? = null
        for ((uid, e) in unknownGallery) { val s = cos(e, emb); if (s > best) { best = s; id = uid } }
        return id
    }

    fun addUnknown(thumb: Bitmap, emb: FloatArray, ts: Long): Long {
        val dir = File(ctx.filesDir, "unknown").apply { mkdirs() }
        val f = File(dir, "u_$ts.jpg")
        FileOutputStream(f).use { thumb.compress(Bitmap.CompressFormat.JPEG, 92, it) }
        val id = App.db.addUnknown(f.absolutePath, ts)
        unknownGallery.add(id to emb)
        return id
    }

    fun saveFaceSample(personId: Long, thumb: Bitmap): Long {
        val dir = File(ctx.filesDir, "faces").apply { mkdirs() }
        val f = File(dir, "p${personId}_${System.nanoTime()}.jpg")
        FileOutputStream(f).use { thumb.compress(Bitmap.CompressFormat.JPEG, 92, it) }
        return App.db.addFace(personId, f.absolutePath)
    }

    fun reloadPeople() { people = App.db.people().associateBy { it.id } }

    /** Re-computes all embeddings from stored face thumbnails (also needed after changing the model). */
    fun reloadGallery() {
        reloadPeople()
        gallery = App.db.allFaces().mapNotNull { (pid, path) ->
            BitmapFactory.decodeFile(path)?.let { Entry(pid, embed(it)) }
        }
        unknownGallery.clear()
        App.db.unknowns().forEach { u -> BitmapFactory.decodeFile(u.path)?.let { unknownGallery.add(u.id to embed(it)) } }
    }
}
