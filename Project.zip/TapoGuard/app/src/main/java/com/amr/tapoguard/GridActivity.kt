package com.amr.tapoguard

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.GridLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView

/** Multi-camera live wall (SD streams, no AI) – tap a tile to open full live view with AI. */
@androidx.annotation.OptIn(UnstableApi::class)
class GridActivity : AppCompatActivity() {
    private val players = mutableListOf<ExoPlayer>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
    }

    override fun onStart() {
        super.onStart()
        val cams = Prefs.cameras()
        if (cams.isEmpty()) { toast("Add a camera first"); finish(); return }
        val cols = if (cams.size == 1) 1 else 2
        val rows = (cams.size + cols - 1) / cols
        val grid = GridLayout(this).apply { columnCount = cols; rowCount = rows; setBackgroundColor(Color.BLACK) }
        cams.forEachIndexed { i, c ->
            val frame = FrameLayout(this)
            val pv = PlayerView(this).apply { useController = false }
            frame.addView(pv, FrameLayout.LayoutParams(MATCH, MATCH))
            frame.addView(TextView(this).apply {
                text = c.name; setTextColor(Color.WHITE); setBackgroundColor(0x88000000.toInt()); setPadding(12, 6, 12, 6)
            }, FrameLayout.LayoutParams(WRAP, WRAP, Gravity.TOP or Gravity.START))
            val click = View(this)
            click.setOnClickListener { startActivity(Intent(this, LiveActivity::class.java).putExtra("cam", c.id)) }
            frame.addView(click, FrameLayout.LayoutParams(MATCH, MATCH))
            val lp = GridLayout.LayoutParams(GridLayout.spec(i / cols, 1f), GridLayout.spec(i % cols, 1f)).apply {
                width = 0; height = 0; setMargins(2, 2, 2, 2)
            }
            grid.addView(frame, lp)
            val p = ExoPlayer.Builder(this).build()
            p.volume = 0f
            p.setMediaSource(rtspSource(c.rtspUrl("stream2")))
            p.prepare(); p.playWhenReady = true
            pv.player = p
            players.add(p)
        }
        setContentView(grid)
    }

    override fun onStop() {
        super.onStop()
        players.forEach { it.release() }
        players.clear()
    }
}
