package com.amr.tapoguard

import android.content.Context
import android.graphics.Bitmap
import android.graphics.RectF
import android.util.Log
import org.tensorflow.lite.support.image.TensorImage
import org.tensorflow.lite.task.core.BaseOptions
import org.tensorflow.lite.task.vision.detector.ObjectDetector

/** Person + vehicle detection with EfficientDet-Lite0 (COCO) running on-device. */
class ObjectEngine(ctx: Context) {
    private var detector: ObjectDetector? = null
    var error: String? = null
        private set
    val available: Boolean get() = detector != null

    init {
        try {
            val opts = ObjectDetector.ObjectDetectorOptions.builder()
                .setBaseOptions(BaseOptions.builder().setNumThreads(4).build())
                .setMaxResults(20)
                .setScoreThreshold(0.35f)
                .build()
            detector = ObjectDetector.createFromFileAndOptions(ctx, "detector.tflite", opts)
        } catch (e: Throwable) {
            error = "detector.tflite not found in app – rebuild with internet so it downloads (see README)"
            Log.e(TAG, "object model", e)
        }
    }

    @Synchronized
    fun detect(bmp: Bitmap): List<Det> {
        val d = detector ?: return emptyList()
        val w = bmp.width.toFloat(); val h = bmp.height.toFloat()
        val res = try { d.detect(TensorImage.fromBitmap(bmp)) } catch (e: Exception) { return emptyList() }
        val out = ArrayList<Det>()
        for (r in res) {
            val c = r.categories.firstOrNull() ?: continue
            val label = c.label.lowercase()
            val kind = when (label) {
                "person" -> "person"
                "car", "truck", "bus", "motorcycle" -> "vehicle"
                else -> null
            } ?: continue
            if (kind == "person" && c.score < 0.45f) continue
            val b = r.boundingBox
            out.add(Det(kind, label, c.score, RectF(b.left / w, b.top / h, b.right / w, b.bottom / h)).apply {
                color = if (kind == "vehicle") Det.CYAN else Det.AMBER
            })
        }
        return out
    }
}
