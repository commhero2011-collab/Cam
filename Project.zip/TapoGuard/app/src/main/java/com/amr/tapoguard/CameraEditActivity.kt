package com.amr.tapoguard

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.text.InputType
import android.widget.RadioButton
import android.widget.RadioGroup
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.dialog.MaterialAlertDialogBuilder

class CameraEditActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val camId = intent.getStringExtra("cam")
        val existing = camId?.let { Prefs.camera(it) }
        val cam = existing ?: CameraConfig()
        title = if (existing == null) "Add camera" else "Edit camera"

        val root = vbox()
        val name = field("Camera name", cam.name)
        val ip = field("Camera IP address (e.g. 192.168.1.50)", cam.ip, InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI)
        val user = field("Camera Account username", cam.user)
        val pass = field("Camera Account password", cam.pass, InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD)
        val hd = RadioButton(this).apply { text = "HD 1080p (stream1) – best for face recognition"; id = android.view.View.generateViewId() }
        val sd = RadioButton(this).apply { text = "SD 360p (stream2) – lighter, weak recognition"; id = android.view.View.generateViewId() }
        val group = RadioGroup(this).apply { addView(hd); addView(sd) }
        if (cam.stream == "stream2") sd.isChecked = true else hd.isChecked = true

        root.add(label("Tapo setup (one time): Tapo app → camera → ⚙ Settings → Advanced Settings → Camera Account → create username & password. " +
            "Use those here (NOT your TP-Link cloud login). Give the camera a fixed IP in your router.", 13f, color = Color.GRAY))
        root.add(name); root.add(ip); root.add(user); root.add(pass); root.add(group)

        fun save(): Boolean {
            if (ip.text.isBlank() || user.text.isBlank() || pass.text.isBlank()) { toast("IP, username and password are required"); return false }
            cam.name = name.text.toString().trim().ifEmpty { "Tapo C200" }
            cam.ip = ip.text.toString().trim()
            cam.user = user.text.toString().trim()
            cam.pass = pass.text.toString()
            cam.stream = if (sd.isChecked) "stream2" else "stream1"
            Prefs.upsertCamera(cam)
            return true
        }

        root.add(btn("Save") { if (save()) finish() }, top = 16)
        root.add(btn("Save & open live view") {
            if (save()) { startActivity(Intent(this, LiveActivity::class.java).putExtra("cam", cam.id)); finish() }
        })
        if (existing != null) {
            root.add(btn("Clear car zones (${cam.zones.size})") { cam.zones.clear(); Prefs.upsertCamera(cam); toast("Zones cleared") })
            root.add(btn("Delete camera") {
                MaterialAlertDialogBuilder(this).setTitle("Delete ${cam.name}?")
                    .setPositiveButton("Delete") { _, _ -> Prefs.deleteCamera(cam.id); finish() }
                    .setNegativeButton("Cancel", null).show()
            })
        }
        root.add(label("Credentials are stored encrypted (Android Keystore, AES-256). Stream URL: rtsp://<user>:<pass>@<ip>:554/stream1", 12f, color = Color.GRAY), top = 16)
        setScroll(root)
    }
}
