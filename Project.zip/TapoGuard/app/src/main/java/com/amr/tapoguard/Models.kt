package com.amr.tapoguard

import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.RectF
import android.net.Uri
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

data class CameraConfig(
    val id: String = UUID.randomUUID().toString(),
    var name: String = "Tapo C200",
    var ip: String = "",
    var user: String = "",
    var pass: String = "",
    var stream: String = "stream1",
    var zones: MutableList<RectF> = mutableListOf()
) {
    /** Tapo RTSP: rtsp://<camera-account>:<password>@<ip>:554/stream1 (HD) or /stream2 (SD) */
    fun rtspUrl(streamOverride: String? = null): String =
        "rtsp://${Uri.encode(user)}:${Uri.encode(pass)}@$ip:554/${streamOverride ?: stream}"

    fun toJson(): JSONObject = JSONObject().apply {
        put("id", id); put("name", name); put("ip", ip); put("user", user)
        put("pass", pass); put("stream", stream)
        val z = JSONArray()
        for (r in zones) {
            val a = JSONArray()
            a.put(r.left.toDouble()); a.put(r.top.toDouble()); a.put(r.right.toDouble()); a.put(r.bottom.toDouble())
            z.put(a)
        }
        put("zones", z)
    }

    companion object {
        fun fromJson(o: JSONObject): CameraConfig {
            val zones = mutableListOf<RectF>()
            val z = o.optJSONArray("zones") ?: JSONArray()
            for (i in 0 until z.length()) {
                val a = z.getJSONArray(i)
                zones.add(RectF(a.getDouble(0).toFloat(), a.getDouble(1).toFloat(), a.getDouble(2).toFloat(), a.getDouble(3).toFloat()))
            }
            return CameraConfig(
                id = o.getString("id"), name = o.optString("name", "Camera"), ip = o.optString("ip"),
                user = o.optString("user"), pass = o.optString("pass"), stream = o.optString("stream", "stream1"),
                zones = zones
            )
        }
    }
}

data class Person(val id: Long, var name: String, var role: String, var authorized: Boolean)

data class UnknownFace(val id: Long, val path: String, val firstSeen: Long, val lastSeen: Long, val sightings: Int)

data class EventItem(
    val id: Long, val ts: Long, val type: String, val camera: String,
    val message: String, val image: String?, val clip: String?, val alert: Boolean
)

/** A detection in normalised (0..1) frame coordinates. kind = person | vehicle | face */
class Det(val kind: String, val label: String, val score: Float, val box: RectF) {
    var name: String? = null
    var personId: Long? = null
    var unknownThumb: Bitmap? = null
    var unknownEmb: FloatArray? = null
    var color: Int = Color.WHITE

    companion object {
        val GREEN = 0xFF3DCD58.toInt()      // known & authorised
        val BLUE = 0xFF42A5F5.toInt()       // known, not authorised for car
        val RED = 0xFFFF5252.toInt()        // unknown face
        val AMBER = 0xFFFFC107.toInt()      // person, face not seen yet
        val MAGENTA = 0xFFE040FB.toInt()    // blocked person
        val CYAN = 0xFF18FFFF.toInt()       // vehicle
        val WHITE = 0xFFFFFFFF.toInt()      // face box
    }
}

val ROLES = listOf("Owner", "Family", "Driver", "Staff", "Guest", "Blocked")
