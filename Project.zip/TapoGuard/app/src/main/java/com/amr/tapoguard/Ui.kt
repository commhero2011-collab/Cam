package com.amr.tapoguard

import android.app.Activity
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.ImageDecoder
import android.graphics.Typeface
import android.net.Uri
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.FileProvider
import androidx.media3.common.MediaItem
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.rtsp.RtspMediaSource
import androidx.media3.exoplayer.source.MediaSource
import com.google.android.material.button.MaterialButton
import com.google.android.material.card.MaterialCardView
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.max

const val TAG = "TapoGuard"
const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

fun Context.vbox(pad: Int = 16): LinearLayout = LinearLayout(this).apply {
    orientation = LinearLayout.VERTICAL
    val p = dp(pad); setPadding(p, p, p, p)
}

fun Context.hbox(): LinearLayout = LinearLayout(this).apply {
    orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
}

fun Context.label(s: CharSequence, size: Float = 15f, bold: Boolean = false, color: Int? = null): TextView =
    TextView(this).apply {
        text = s; textSize = size
        if (bold) setTypeface(typeface, Typeface.BOLD)
        if (color != null) setTextColor(color)
    }

fun Context.btn(s: String, onClick: () -> Unit): MaterialButton = MaterialButton(this).apply {
    text = s; isAllCaps = false; setOnClickListener { onClick() }
}

fun Context.field(hintText: String, value: String = "", type: Int = InputType.TYPE_CLASS_TEXT): EditText =
    EditText(this).apply { hint = hintText; setText(value); inputType = type; isSingleLine = true }

fun Context.check(s: String, value: Boolean): CheckBox = CheckBox(this).apply { text = s; isChecked = value }

fun Context.card(vararg views: View): MaterialCardView {
    val inner = vbox(12)
    views.forEach { inner.add(it, top = 2) }
    return MaterialCardView(this).apply {
        radius = dp(14).toFloat(); cardElevation = dp(2).toFloat(); useCompatPadding = true
        addView(inner)
    }
}

fun LinearLayout.add(v: View, w: Int = MATCH, h: Int = WRAP, top: Int = 6): View {
    addView(v, LinearLayout.LayoutParams(w, h).apply {
        topMargin = (top * context.resources.displayMetrics.density).toInt()
    })
    return v
}

fun LinearLayout.addWeighted(v: View, weight: Float = 1f) {
    addView(v, LinearLayout.LayoutParams(0, WRAP, weight).apply { marginEnd = context.dp(4) })
}

fun Activity.toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

fun Activity.setScroll(root: View) = setContentView(ScrollView(this).apply { addView(root) })

fun timeStr(ts: Long): String = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date(ts))
fun fileStamp(ts: Long = System.currentTimeMillis()): String = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date(ts))

@androidx.annotation.OptIn(UnstableApi::class)
fun rtspSource(url: String): MediaSource =
    RtspMediaSource.Factory()
        .setForceUseRtpTcp(true)   // more reliable over Wi-Fi than UDP
        .setTimeoutMs(10_000)
        .createMediaSource(MediaItem.fromUri(url))

fun Context.uriFor(f: File): Uri = FileProvider.getUriForFile(this, "$packageName.files", f)

fun loadThumb(path: String?, sample: Int = 4): Bitmap? {
    if (path == null || !File(path).exists()) return null
    return BitmapFactory.decodeFile(path, BitmapFactory.Options().apply { inSampleSize = sample })
}

fun Context.decodeUri(uri: Uri, maxDim: Int = 1600): Bitmap? = try {
    ImageDecoder.decodeBitmap(ImageDecoder.createSource(contentResolver, uri)) { decoder, info, _ ->
        decoder.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
        val s = info.size; val m = max(s.width, s.height)
        if (m > maxDim) {
            val k = maxDim.toFloat() / m
            decoder.setTargetSize((s.width * k).toInt(), (s.height * k).toInt())
        }
    }
} catch (e: Exception) { null }
