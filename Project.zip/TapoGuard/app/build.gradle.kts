plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.amr.tapoguard"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.amr.tapoguard"
        minSdk = 29
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
    }
    buildTypes {
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("debug")
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    androidResources { noCompress += listOf("tflite") }
    lint {
        abortOnError = false
        checkReleaseBuilds = false
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")
    implementation("androidx.recyclerview:recyclerview:1.3.2")
    implementation("androidx.security:security-crypto:1.1.0-alpha06")
    implementation("androidx.media3:media3-exoplayer:1.4.1")
    implementation("androidx.media3:media3-exoplayer-rtsp:1.4.1")
    implementation("androidx.media3:media3-ui:1.4.1")
    implementation("com.google.mlkit:face-detection:16.1.7")
    implementation("org.tensorflow:tensorflow-lite-task-vision:0.4.4")
    implementation("org.tensorflow:tensorflow-lite:2.14.0")
}

val modelUrls = mapOf(
    "detector.tflite" to listOf(
        "https://storage.googleapis.com/download.tensorflow.org/models/tflite/task_library/object_detection/android/lite-model_efficientdet_lite0_detection_metadata_1.tflite"
    ),
    "face.tflite" to listOf(
        "https://github.com/estebanuri/face_recognition/raw/master/android/face-recognition/app/src/main/assets/mobile_face_net.tflite",
        "https://github.com/MCarlomagno/FaceRecognitionAuth/raw/master/assets/mobilefacenet.tflite",
        "https://github.com/shubham0204/FaceRecognition_With_FaceNet_Android/raw/master/app/src/main/assets/facenet.tflite"
    )
)

tasks.register("downloadModels") {
    doLast {
        val dir = file("src/main/assets")
        dir.mkdirs()
        modelUrls.forEach { (name, urls) ->
            val out = File(dir, name)
            if (out.exists() && out.length() > 10_000) {
                println("Model $name already present")
                return@forEach
            }
            for (u in urls) {
                try {
                    val tmp = File.createTempFile("model", ".tmp")
                    ant.invokeMethod("get", mapOf("src" to u, "dest" to tmp, "skipexisting" to false))
                    val bytes = tmp.readBytes()
                    tmp.delete()
                    if (bytes.size > 10_000 && String(bytes, 4, 4) == "TFL3") {
                        out.writeBytes(bytes)
                        println("Model $name downloaded from $u (${bytes.size} bytes)")
                        break
                    } else {
                        println("Not a TFLite file: $u (${bytes.size} bytes)")
                    }
                } catch (e: Exception) {
                    println("WARNING: download failed $u -> ${e.message}")
                }
            }
            if (name == "detector.tflite" && (!out.exists() || out.length() < 10_000)) {
                throw GradleException("Required AI model $name could not be downloaded. See README.")
            }
        }
    }
}
tasks.named("preBuild") { dependsOn("downloadModels") }
