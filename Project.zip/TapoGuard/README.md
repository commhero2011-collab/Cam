# TapoGuard – Tapo C200 surveillance app with face recognition & car guard (Android)

## Features
| Area | What it does |
|---|---|
| Live view | RTSP live stream from Tapo C200 (HD `stream1` / SD `stream2`), auto-reconnect, sound on/off |
| Multi-camera | Grid wall of all cameras (SD streams); tap to open full view |
| PTZ | Pan/tilt pad over ONVIF (port 2020) – press & hold arrows |
| Snapshot / Recording | Snapshot to `Pictures/TapoGuard`; manual MP4 recording; automatic clip on every alert |
| Detection | On-device person + car/truck/bus/motorcycle detection (EfficientDet-Lite0) |
| Faces | Face detection (Google ML Kit) + optional face recognition (compatible TFLite embedding model); no auto-authorisation without a working model |
| Characters | People library: name, role (Owner/Family/Driver/Staff/Guest/Blocked), "allowed at car" flag, face samples |
| Unknown faces | Unrecognised faces are saved and grouped; tap to name them or link them to an existing person |
| Car guard | Draw a **car zone** on the live view and/or auto-protect parked cars. If a person stays at the car for N seconds and is **not** an authorised person → high-priority alert + snapshot + clip |
| Other alerts | Blocked person seen, protected car left, unknown person (optional), known person (optional), motion (optional) |
| Remote alerts | Optional Telegram bot: alert text + photo to your phone anywhere |
| Events | Timeline with annotated snapshots, clips, share, delete, auto-cleanup after N days |
| Security | Camera credentials encrypted (Android Keystore AES-256); all AI runs on the phone – no cloud |

---

## 1. Get the APK (no Android Studio needed) – GitHub Actions
1. Create a free GitHub account → **New repository** (private is fine).
2. Upload **all files of this folder** (keep the folder structure, including `.github/workflows/build-apk.yml`).
3. Open the **Actions** tab → *Build TapoGuard APK* runs automatically (≈5–8 min).
4. Open the finished run → **Artifacts** → download `TapoGuard-APK.zip` → inside is `app-debug.apk`.
5. Copy it to the Android phone → open it → allow *Install unknown apps*.

> The build automatically downloads the AI models into `app/src/main/assets/`.
> In the build log, look for `Model detector.tflite downloaded` and `Model face.tflite downloaded`.
> If the optional face model download fails, **no face is auto-authorised**: all car visitors are treated as unknown/unidentified until you import and validate a compatible face-embedding `.tflite` model under **Settings → Import face model**. The detector model is required: a missing detector fails the build.

### Alternative: Android Studio
Open the folder in Android Studio (Koala or newer) → let Gradle sync → **Build → Build APK(s)**.

## 2. Prepare the Tapo C200 (one time)
1. In the Tapo app, open the camera → ⚙ **Settings → Advanced Settings → Camera Account**. Create a username and password. This is **not** your TP-Link cloud login.
2. In your router, give the camera a **fixed IP (DHCP reservation)**.
3. Make sure the phone and the camera are on the **same network**. For best security, use a dedicated IoT VLAN/SSID and allow the phone to reach camera ports **554 (RTSP)** and **2020 (ONVIF)**.
4. Leave a microSD card in the camera if you want 24/7 recording. TapoGuard records event clips and snapshots on the phone.

## 3. First use
1. Tap **Add camera**, then enter the name, IP, Camera Account user and password, and pick **HD**. Tap **Save & open live view**.
2. In the live view, tap **🚗 Car zone**, drag a rectangle around where your car parks, then tap **✔ Done**.
3. Under **People & face library**, tap **+ Add person** and set the role. Tick *Allowed to touch/use the car* for family and your driver. Add 3–10 clear face photos.
4. Leave the live view open. The screen stays on, and you can use **Dim screen**. Faces the app doesn't know appear under **Unknown faces**, where you can name them.
5. Optional: open **Settings**, add a Telegram bot token and chat ID, then tap **Send Telegram test**.

## 4. How the car-guard decision works
```
person box overlaps car zone / parked car  ──►  stays ≥ dwell seconds (default 3 s)
        │
        ├─ face recognised & "allowed at car" ─► logged only (no alert)
        ├─ face recognised & NOT allowed      ─► ⚠ ALERT (name shown)
        ├─ unknown face                       ─► ⚠ ALERT (Unknown #id, saved for labelling)
        └─ face not visible (waits 2× dwell)  ─► ⚠ ALERT (Unidentified person)
ALERT = notification with annotated photo + Telegram (optional) + MP4 clip + event log; cooldown applies
```
Box colours: green = known & allowed, blue = known but not allowed, red = unknown, amber = face not seen yet, magenta = blocked, cyan = vehicle, yellow = car zone.

## 5. Important limitations (please read)
- **Monitoring runs while the live screen is open.** Run it on a dedicated phone or tablet kept on a charger, like a small NVR. If you leave the screen or turn the display off, analysis stops.
- **Face recognition needs pixels.** At 1080p, faces should be roughly 60 px or wider, which usually means within about 4–6 m of the C200. At night with IR, accuracy drops. Keep the stream on HD and increase *Analysis width* to 1920 if the phone is powerful.
- No AI system is 100% accurate. Use the dwell time and thresholds to balance false alarms against missed events.
- This third-party RTSP app does not implement two-way talk or playback of camera SD-card recordings. Use the Tapo app for those.
- Older C200 firmware may need ONVIF turned on, or may not support PTZ over ONVIF.

## 6. Privacy / legal
Face recognition processes biometric data. Use it only on your own property and post a visible CCTV notice. Get consent from people you enroll, such as family members or a driver. Delete unknown faces you don't need. Images and identities remain on the device unless you enable Telegram alerts or share them yourself. Telegram sends alert text and photos to its service.

## Project structure
`app/src/main/java/com/amr/tapoguard/`: `LiveActivity` (stream, recording, PTZ), `Analyzer` (AI pipeline & rules), `FaceEngine`, `ObjectEngine`, `ClipRecorder`, `Onvif`, `OverlayView`, plus the screens for people, unknown faces, events, settings, cameras and the camera grid.

## Review and validation status
- Source-level review completed: removed insecure plaintext credential fallback; Telegram credentials now encrypted; object-model absence stops the build; without a face model, pixel-signature matches never authorise a person; improved face detection fallback and ONVIF profile-token parsing.
- NOT validated: Android compilation, runtime on a Tapo C200, ONVIF PTZ, detection accuracy, clip encoding, notifications, or the remote Telegram endpoint. Do not treat the app as a proven security system.
- Threat model: local RTSP/ONVIF is not end-to-end encrypted. Keep the camera on a trusted local network; use VPN for remote access, not public port forwarding.
- The car interaction rule uses bounding-box proximity and dwell; it cannot determine intent or prove actual physical contact.
- The camera's own Tapo Care, microSD and third-party RTSP/ONVIF recording have simultaneous-stream limitations. Check your camera configuration.
